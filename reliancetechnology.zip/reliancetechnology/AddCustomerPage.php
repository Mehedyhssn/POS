<?php
require_once('connection.php');
require_once('header.php');
echo '<h1 style="text-align:center;margin-bottom:10px">Add Customer</h1>';
?>
<form method="get" action="AddCustomerPage.php">
<fieldset style="background:lightyellow">
		<legend>Add Customer's Info</legend>
		<table style="margin-bottom:10px">
		<tr><td style="width:180px"><label style="width:180px">Name :</label></td><td style="width:750px"><input style="font-size: 20px;width:100%;height:40px" type="text"  name="name" id="product"/></td><tr>
		<tr><td><label>Address :</label></td><td><input style="font-size:20px;width:100%;height:40px" type="text" name="address"></td><tr>
		<tr><td><label>Mobile :</label></td><td><input style="font-size:20px;width:25%;height:40px" type="text" name="mobil" maxlength="11" onkeyup="this.value=this.value.replace(/[^\d]/,'')"></td><tr></table>
		
		<input style="cursor:pointer;color:red;width:100%;font-style:italic;font-size:30px" type="submit" name="add" value="ADD"/>
	</fieldset>
</form>
<?php
if(isset($_GET['add'])){
	    $q = mysql_query("select mobile from customer where mobile='$_GET[mobil]'");
		if(mysql_num_rows($q)==1){
			echo "<script>alert('Already customer there!!')</script>";
			
		}elseif($_GET['name'] == '' or $_GET['address'] == '' or $_GET['mobil'] == ''){
			echo "<script>alert('Please fill up all fields!!')</script>";
			
			
		}else{
			
			mysql_query("INSERT INTO `customer`(`customer_ID`, `name`, `address`, `mobile`) VALUES ('','$_GET[name]','$_GET[address]','$_GET[mobil]')");
			
		}
	
	
	
}
require_once('footer.php');
?>
<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>