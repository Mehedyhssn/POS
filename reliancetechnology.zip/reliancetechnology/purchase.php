<?php
require_once('connection.php');
require_once('header.php');
echo '<h1 style="text-align:center;margin-bottom:15px">Daily Buy</h1>';
function daily_buy(){
	
	$page = @$_GET['page'];
	
	if($page=='' || $page==1){
		$page1 = 0;
	}else{
		$page1 = ($page*15)-15;
	}	
	
	//Query from daily buy table
	$query = mysql_query("SELECT * FROM `daily_buy`,`sl` WHERE daily_buy.dailybuy_ID = sl.daily_buy_id limit $page1,15");
	echo '<form method="get"><h1>Daily Purchase Products!!</h1><br><br><table style="text-align: center;"><tr><th class="grey">Date</th><th class="grey">Product</th><th class="grey">Brand</th><th class="grey">Model</th><th class="grey">Serial No.</th><th class="grey">Warrenty</th><th class="grey">Unit Price</th><th class="grey">Qty.</th><th class="grey">Total</th><th class="grey">Company</th><th class="grey" colspan="2">Actions</th></tr>';
	while( $rows = mysql_fetch_array($query) ){
		echo '<tr><td>'.$rows['dated'].'</td>
				  <td>'.$rows['product'].'</td>
				  <td>'.$rows['brand'].'</td>
				  <td>'.$rows['model'].'</td>
				  <td>'.$rows['si_no'].'</td>
				  <td>'.$rows['wnty'].'</td>
				  <td>'.$rows['unit_price'].'</td>
				  <td>'.$rows['qty'].'</td>
				  <td>'.$rows['total'].'</td>
				  <td>'.$rows['company'].'</td>
				  <td><a style="color:green;font-weight:bold;font-style: italic;" href="purchase.php?edit='.$rows['dailybuy_ID'].'">Edit</a></td>
				  <td><a style="color:red;font-weight:bold;font-style: italic;" href="purchase.php?delete='.$rows['dailybuy_ID'].'" class="delete">Delete</a></td></tr>';
	}
	echo '</table></form><div id="delete_ok"></div>';
	//this is for paging sections
	$result = mysql_query("select * from daily_buy");
	$num_of_rows = mysql_num_rows($result);
	$a = $num_of_rows/15;
	$a = ceil($a);
	for($i=1;$i<=$a;$i++){
		echo '<br><br><a href="purchase.php?page='.$i.'" style="text-decoration:none">'.$i.'</a>';
	}
}
//Edit Section
function edit(){
		if(isset($_GET['edit'])){
				echo '<form method="get" action="purchase.php"><table style="margin:0 auto; width:250px;">';
					$query = mysql_query("SELECT * FROM `daily_buy`,`sl` WHERE daily_buy.dailybuy_ID = '$_GET[edit]' and sl.daily_buy_id='$_GET[edit]'");
					while( $rows = mysql_fetch_array($query) ){
						echo '<tr>
								<th style="background:lightyellow">Dated : </th><th style="background:lightyellow">Product : </th><th style="background:lightyellow">Brand:</th>
								<th style="background:lightyellow">Model:</th><th style="background:lightyellow">Serial No :</th><th style="background:lightyellow">Warrenty:</th>
								<th style="background:lightyellow">Unit Price:</th><th style="background:lightyellow"> Qty.</th><th style="background:lightyellow">Total:</th>
								<th style="background:lightyellow">Company:</th><th style="background:lightyellow">Actions</th>
							  </tr>
						      <tr>
								  <td><input type="text" name="dated" size="8" value="'.$rows['dated'].'"></td>
								  <td><input type="text" size="8" name="product" value="'.$rows['product'].'"></td>
								  <td><input type="text" size="4" name="brand" value="'.$rows['brand'].'"></td>
								  <td><input type="text" size="4" name="model" value="'.$rows['model'].'"></td>
								  <td><input type="text" name="sl" value="'.$rows['si_no'].'"></td>
								  <td><input type="text" size="4" name="wnty" value="'.$rows['wnty'].'"></td>
								  <td><input class="unit_price" size="3" type="text" name="unit_price" value="'.$rows['unit_price'].'"></td>
								  <td><input class="qty" type="text" size="3" name="qty" value="'.$rows['qty'].'"></td>
								  <td><input class="total" type="text" size="8" name="total" value="'.$rows['total'].'"></td>
								  <td><input type="text" size="8" name="company" value="'.$rows['company'].'"></td>
								  <td><input type="submit" style="color:red;font-weight:bold;" value="Update"/><input type="hidden" name="update" value="'.$rows['dailybuy_ID'].'"></td>
							  </tr>';
					}
				echo '</table>';
		}
}
function update(){
	if(isset($_GET['update'])){
				
			mysql_query("update daily_buy set 
							dated = '$_GET[dated]',
							product = '$_GET[product]',
						    brand = '$_GET[brand]',
							model = '$_GET[model]',
							wnty = '$_GET[wnty]',
							unit_price = '$_GET[unit_price]',
							qty = '$_GET[qty]',
							total = '$_GET[total]',
							company = '$_GET[company]'
									
							where dailybuy_ID = '$_GET[update]'
						");
			mysql_query("update sl set si_no = '$_GET[sl]'	where daily_buy_id = '$_GET[update]'");
						
		}
	echo 'Successfully Updated';
	header('Location: http://localhost/reliancetechnology/purchase.php');
}
function product_delete(){
	if( isset($_GET['delete']) ){
		//Alerming to delete
		 $id = $_GET['delete'];
		?>
		<script>
		$( document ).ready(function(e) {
		  var r = confirm("Are you sure to delete?");
		  var id = '<?php echo $id; ?>';
		  if(r==true){
			 $.ajax({
					type: "GET",
					data:{
						"delete": 1,
						 "id" : id
					}, 
					url: "allfilesAjax.php",
					success: function(e){
						window.location.assign("http://localhost/reliancetechnology/purchase.php")
										
				    }
				});
		  }else{
			  window.location.assign("http://localhost/reliancetechnology/purchase.php")
		  }
		})
		</script>
		<?php 
	}
}
if(isset($_GET['edit'])){
	edit();
}elseif(isset($_GET['update'])){
	update();
}elseif(isset($_GET['delete'])){
	product_delete();
}else{
	daily_buy();
}
require_once("footer.php");
?>

<!-- Jquery for addition on purchase page -->
<script>
$(document).ready(function(){
	$('.unit_price').keyup(function(){
		var unit_price = $(this).val();
		var qty = $('.qty').val();
		var total = unit_price * qty;
		$('.total').val(total);
	})
	$('.qty').keyup(function(){
		var qty = $(this).val();
		var unit_price = $('.unit_price').val();
		var total = unit_price * qty;
		$('.total').val(total);
	})
	
})
</script>