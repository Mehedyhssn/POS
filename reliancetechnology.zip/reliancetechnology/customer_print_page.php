<?php
require_once('connection.php');
require_once('header.php');

if(isset($_GET['customer_id'])){
	//Inserting Customer dues
	mysql_query("insert into customer_sale_report(`cust_sale_rep`,`customer_ID`,`dated`,`grand_total`,`previous_deu`,`collection`,`net_outstanding`) 
	                                       values('','$_GET[customer_id]','$_GET[curdate]','$_GET[grand_total]','$_GET[pre_due]','$_GET[collection]','$_GET[net_out]')");
	
	$query = mysql_query("select * from daily_sale where customer_ID='$_GET[customer_id]' and dated='$_GET[curdate]' and order_no='$_GET[order_no]'");
    echo '<form method="POST" action="export.php"><table style="width:100%;text-align:center">
	        <input type="hidden" name="customer_id" value="'.$_GET['customer_id'].'">
			<input type="hidden" name="curdate" value="'.$_GET['curdate'].'">
			<input type="hidden" name="order_no" value="'.$_GET['order_no'].'">
			<input type="hidden" name="sold_by" value="'.$_GET['sold_by'].'">
			<th>SL No.</th><th>Product Details</th><th>Qty.</th><th>Unit Price</th><th>Total</th>';
			//starting loop
			$i = 1;
			$q = mysql_query("select * from daily_sale where customer_ID='$_GET[customer_id]' and dated='$_GET[curdate]' and order_no='$_GET[order_no]'");
			while($r=mysql_fetch_array($q)){
				$total = $r['qty'] * $r['unit_price'];
				echo '<tr><td>'.$i++.'</td><td>'.$r['product'].' '.$r['brand'].' '.$r['model'].'<br>S/N '.$r['sl'].'<br>Warrenty '.$r['wnty'].'<input type="hidden" name="product_details" value="'.$r['product'].' '.$r['brand'].' '.$r['model'].'<br>S/N '.$r['sl'].'<br>Warrenty '.$r['wnty'].'"></td><td>'.$r['qty'].'</td><td>'.$r['unit_price'].'</td><td>'.$r['grand_total'].'</td></tr>';
				
			}
		echo '</table>';
        echo '<fieldset>
		<legend>Collections</legend>
		Grand total : ';
		$q2 = mysql_query("select sum(grand_total) from daily_sale where customer_ID='$_GET[customer_id]' and dated='$_GET[curdate]' and order_no='$_GET[order_no]'");
			while($r=mysql_fetch_array($q2)){
				echo $r['sum(grand_total)'].'<input type="hidden" name="grand_total" value="'.$r['sum(grand_total)'].'"><br>';				
			}
		echo 'Previous Dues : ';
		echo $_GET['pre_due'].'<input type="hidden" name="pre_due" value="'.$_GET['pre_due'].'"><br>';
		echo 'Collections : ';
		echo $_GET['collection'].'<input type="hidden" name="collection" value="'.$_GET['collection'].'"><br>';
		echo 'Net Outstandings : ';
		echo $_GET['net_out'].'<input type="hidden" name="net_out" value="'.$_GET['net_out'].'"><br>';
		echo '</fieldset>';
		echo '<input style="cursor:pointer;color:red;font-weight:bold;font-size:20px;margin:10px 0" name="customer_sale_report" type="submit" value="Export To PDF"></form>';		
}
require_once("footer.php");
?>

