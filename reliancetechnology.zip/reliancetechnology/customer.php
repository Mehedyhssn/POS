<?php
require_once('connection.php');
require_once('header.php');
'<h1 style="text-align:center;margin-bottom:15px">Collection Page</h1>';
if(isset($_GET['customer_id'])){
	
echo "<table style='margin-bottom:15px;width:100%;'>
			<tr><td class='order'>Order No: <input style='border:none' type='text' name='order_no' class='order_no' value="; echo $_GET['order_no']; echo "></td><td>Contact No: ";
				$q = mysql_query("select * from customer where customer_id='$_GET[customer_id]'");
		
				while($r=mysql_fetch_array($q)){
					echo $r['mobile'];
				}
			echo "</td><td>Date : ".$_GET['curdate']."</td></tr>";
			echo "<tr><td>Customer Name: ";
				$q = mysql_query("select * from customer where customer_id='$_GET[customer_id]'");
		
					while($r=mysql_fetch_array($q)){
						echo $r['name'];
					}
			echo "</td><td>Address : ";
				$q = mysql_query("select * from customer where customer_id='$_GET[customer_id]'");
		
					while($r=mysql_fetch_array($q)){
						echo $r['address'];
					}
			echo "</td><td>sold By : ".$_GET['sold_by']."</td></tr>			
			
			
		</table><input style='margin-bottom:15px;font-weight:bold;color:red;font-style:italic;font-size:20px;cursor:pointer' type='button' value='Buy Products!!' onclick='window.history.go(-1)'>";
		//Product Soled is started
		
		echo '<table style="width:100%;text-align:center">
			<th>SL No.</th><th>Product Details</th><th>Qty.</th><th>Unit Price</th><th>Total</th><th>Update</th><th>Delete</th>';
			//starting loop
			$i = 1;
			$q = mysql_query("select * from daily_sale where customer_ID='$_GET[customer_id]' and dated='$_GET[curdate]' and order_no='$_GET[order_no]'");
			while($r=mysql_fetch_array($q)){
				$total = $r['qty'] * $r['unit_price'];
				echo '<tr><td>'.$i++.'</td><td>'.$r['product'].' '.$r['brand'].' '.$r['model'].'<br>S/N '.$r['sl'].'<br>Warrenty '.$r['wnty'].'<input type="hidden" name="product_details" value="'.$r['product'].' '.$r['brand'].' '.$r['model'].'<br>S/N '.$r['sl'].'<br>Warrenty '.$r['wnty'].'"></td><td><input type="text" style="text-align:center" disabled="true" size="2" value="'.$r['qty'].'" class="qty'.$r['dailysale_ID'].'"><input type="hidden" name="qty" value="'.$r['qty'].'"></td><td><input style="text-align:center" size="8" type="text" value="'.$r['unit_price'].'" class="unit_price'.$r['dailysale_ID'].'"><input type="hidden" name="unit_price" value="'.$r['unit_price'].'"></td><td>'.$total.'<input type="hidden" name="total" value="'.$total.'"></td><td><input type="button" value="'.$r['dailysale_ID'].'" class="update'.$r['dailysale_ID'].'" id="update" name="update"></td><td><input type="button" value="'.$r['dailysale_ID'].'" id="delete" class="delete'.$r['dailysale_ID'].' name="delete""></td></tr>';
				echo '<tr style="border:none;display:none;"><td style="border:none;display:none;"><script src="jquery.js"></script></td></tr>';
				echo '<tr style="border:none;display:none;">
						<td style="border:none;display:none;">
							<script>
								$(document).ready(function(){
									$("body").delegate(".update'.$r['dailysale_ID'].'","click",function(){
										var dailySaleUpdateid = $(this).val();
										var qty = $(".qty'.$r['dailysale_ID'].'").val();
										var unit_price = $(".unit_price'.$r['dailysale_ID'].'").val();
										$.ajax({
											type : "GET",
											data : {
												 "dailySaleUpdateid" : dailySaleUpdateid,
												 "qty" : qty,
												 "unit_price" : unit_price
											 },
											url : "daily_sale_update_delete.php",
											success : function(e){
												
												location.reload();
											}
										})
									})
								})
							</script>
						</td>
					</tr>';
					echo '<tr style="border:none;display:none;">
						<td style="border:none;display:none;">
							<script>
								$(document).ready(function(){
									$("body").delegate(".delete'.$r['dailysale_ID'].'","click",function(){
										var delete_id = $(this).val();
										var r = confirm("Are you sure to delete?");
										if(r==true){
											$.ajax({
												type : "GET",
												data : {
													 "delete_id" : delete_id
												},
												url : "daily_sale_update_delete.php",
												success : function(e){
													
													location.reload();
												}
											})
											//UPdate Serial No
											$.ajax({
													type: "GET",
													data:{
														"delete_sale": 1,
														 "id" : delete_id
													}, 
													url: "slUpdate.php",
													success: function(e){
														
														location.reload();
																		
													}
										    });
											
										}else{
											location.reload();
										}
										
									})
								})
							</script>
						</td>
					</tr>';
				
			}
		echo '</table>';
		echo '<form method="GET" id="submit" action="customer_print_page.php" style="margin-top:15px;position:relative;left:568px;width:393px">
				<input type="hidden" id="customer_id" name="customer_id" value="'.$_GET['customer_id'].'">
				<input type="hidden" name="curdate" value="'.$_GET['curdate'].'">
				<input type="hidden" name="sold_by" value="'.$_GET['sold_by'].'">
				<input type="hidden" name="order_no" value="'.$_GET['order_no'].'">
				<input type="hidden" name="product_details" value="'.$r['product'].' '.$r['brand'].' '.$r['model'].'<br>S/N '.$r['sl'].'<br>Warrenty '.$r['wnty'].'">
				<input type="hidden" name="qty" value="'.$r['qty'].'">
				<input type="hidden" name="unit_price" value="'.$r['unit_price'].'">
				<input type="hidden" name="total" value="'.$total.'">
				<fieldset style="width:390px">
				Grand Total: ';
				$grandtotal_query = mysql_query("select sum(grand_total) from daily_sale where customer_ID='$_GET[customer_id]' and dated='$_GET[curdate]' and order_no='$_GET[order_no]'");
				while($r=mysql_fetch_array($grandtotal_query)){
					 echo $r['sum(grand_total)'];
				}
				echo '<input class="grand_total" type="hidden" name="grand_total" value="';
				$grandtotal_query = mysql_query("select sum(grand_total) from daily_sale where customer_ID='$_GET[customer_id]' and dated='$_GET[curdate]' and order_no='$_GET[order_no]'");
				while($r=mysql_fetch_array($grandtotal_query)){
					 echo $r['sum(grand_total)'];
				}
				echo '"><br>';
				$pre_query = mysql_query("select * from customer_sale_report where customer_ID='$_GET[customer_id]' order by cust_sale_rep DESC limit 0,1");
                if(mysql_num_rows($pre_query)==''){
					echo 'Previous Dues : 0 <input type="hidden" name="pre_due" value="0" class="pre_due"><br>';
				}else{
					echo 'Previous Dues : <span id="pre_due"></span> <input type="hidden" name="pre_due" value="';
						while($r=mysql_fetch_array($pre_query)){
							echo abs($r['net_outstanding']);
						}
					echo '" class="pre_due"><br>';
				}
						
					
				echo 'Collection : <input autocomplete="off" type="text" class="collection" name="collection" value="">(<span class="need_to_be_paid"></span>)<br>
				Net Outstanding : <span id="net_out"></span><input type="hidden" name="net_out" class="net_out" value="">
		  </fieldset></form><script src="jquery.js"></script>';
		echo '<script>
		 $(document).ready(function(){
			 var pre_dues_for_customer = $(".pre_due").val();
			 $("#pre_due").text(pre_dues_for_customer);
			 
			  var pd = $(".pre_due").val();
			  var int_pd = parseInt(pd);
			  
			  var gt = $(".grand_total").val();
			  var int_gt = parseInt(gt);
			 
			  var need_to_be_paid = int_pd + int_gt;
			  $(".need_to_be_paid").text(need_to_be_paid);
			 
			$(".collection").keyup(function(e){
				 var collection = $(this).val();
				 var int_collection = parseInt(collection);
				 
				 var pre_due = $(".pre_due").val();
				 var int_pre_due = parseInt(pre_due);
				 
				  var grand_total = $(".grand_total").val();
				 
				 var int_grand_total = parseInt(grand_total);
				 
				 
				 var pre_collect = int_pre_due + int_grand_total;
				 
				
				 
				 var final_cost = int_collection - pre_collect;
				 
				 $(".net_out").val(final_cost);
				 $("#net_out").text(final_cost);
				 if(e.keyCode==13){
					
						 $("#submit").submit();
					
				 }
			 })
		 })
		</script>'; 

}
require_once("footer.php");
?>
