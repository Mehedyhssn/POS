<?php
require_once("connection.php");
require_once("header.php");
echo '<h1 style="text-align:center">Warrenty</h1>';
if(isset($_GET['edit'])){
		echo '<input type="button" onClick="window.history.go(-1)" value="Go Back"><form method="GET" action="warrenty.php"><table class="show hide" style="margin-top:10px;width:100%"><th class="th" colspan="11">Warrenty Page</th>';
		       $query = mysql_query("select * from warrenty where warr_id='$_GET[edit]'");
			   echo '<tr><td>Send Date</td><td>Send Media</td><td>Recive Date</td><td>Products Name</td><td>Product Problem</td><td>Qty.</td><td>S/N</td><td>New S/N</td><td>Customer info</td><td>Recive</td></tr>';
			   while($r=mysql_fetch_array($query)){
				   echo '<tr>
				   <td>'.$r['send_date'].'</td>
				   <td>'.$r['send_media'].'</td>
				   <td><input type="text" name="received_date" size="8" value=""></td>
				   <td>'.$r['product_name'].'</td>
				   <td>'.$r['problem'].'</td>
				   <td>'.$r['qty'].'</td>
				   <td>'.$r['sn'].'</td>
				   <td><input type="text" name="new_sn"></td>
				   <td>'.$r['customer_info'].'</td>
				   <td><input type="text" name="receive"></td>
				   <td><input type="submit" value="Update"><input type="hidden" name="update" value="'.$_GET['edit'].'"></td>
				   </tr>';
			    }			  
		echo '</table></form>';
			exit();
}
if(isset($_GET['update'])){
		mysql_query("update warrenty set received_date='$_GET[received_date]', new_sn='$_GET[new_sn]', receive='$_GET[receive]' where warr_id='$_GET[update]'");
		header("Location: http://localhost/reliancetechnology/warrenty.php");	
			exit();
}
if(isset($_GET['delete'])){
		mysql_query("delete from warrenty where warr_id='$_GET[delete]'");
		header("Location: http://localhost/reliancetechnology/warrenty.php");	
			exit();
}
if(isset($_POST['add'])){
	
	if( empty($_POST['send_media'])
		or empty($_POST['product_name'])
	    or empty($_POST['problem'])
		or empty($_POST['qty'])
		or empty($_POST['sn'])
		or empty($_POST['customer_info'])
	  
	){
		echo '<script>alert("fill all fields!!")</script>';
		echo '<script>window.location.href="http://localhost/reliancetechnology/warrenty.php"</script>';
	}else{
		$dated = mysql_query('SELECT curdate();');
		$date = mysql_fetch_assoc($dated);
		$curr_date = $date['curdate()'];
		mysql_query("insert into warrenty (`warr_id`,`send_date`,`send_media`,`received_date`,`product_name`,`problem`,`qty`,`sn`,`new_sn`,`customer_info`,`receive`) 
		               values ('','$curr_date','$_POST[send_media]','','$_POST[product_name]','$_POST[problem]','$_POST[qty]','$_POST[sn]','','$_POST[customer_info]','')");	
		//Showing Tables of balance
		echo '<script>window.location.href="http://localhost/reliancetechnology/warrenty.php"</script>';
		
	}
	
	
}else{
	   	
		//Showing Tables of balance
		echo '<input type="button" class="showing" value="Show">
	  <input type="button" class="hidding" value="hide"><table class="show hide" style="margin-top:10px;width:100%"><th colspan="12">Warrenty Page</th>';
		       $query = mysql_query("select * from warrenty");
			   echo '<tr><td class="th">No</td><td class="th">Send Date</td><td class="th">Send Media</td><td class="th">Recive Date</td><td class="th">Products Name</td><td class="th">Product Problem</td><td class="th">Qty.</td><td class="th">S/N</td><td class="th">New S/N</td><td class="th">Customer info</td><td class="th">Delivery to Customer</td><td class="th" colspan="2">Actions</td></tr>';
			   $i=1;
			   while($r=mysql_fetch_array($query)){
				   echo '<tr><td>'.$i.'</td>
				   <td>'.$r['send_date'].'</td>
				   <td>'.$r['send_media'].'</td>
				   <td>'.$r['received_date'].'</td>
				   <td>'.$r['product_name'].'</td>
				   <td>'.$r['problem'].'</td>
				   <td>'.$r['qty'].'</td>
				   <td>'.$r['sn'].'</td>
				   <td>'.$r['new_sn'].'</td>
				   <td>'.$r['customer_info'].'</td>
				   <td>'.$r['receive'].'</td>
				   <td><a href="warrenty.php?edit='.$r['warr_id'].'">Edit</a></td>
				   <td><a href="warrenty.php?delete='.$r['warr_id'].'">Delete</a></td>
				   </tr>';
				   $i++;
			    }			  
		echo '</table>';
		//This is for Edit
		

?>
<form method="POST" action="warrenty.php" id="proinfo">
			<fieldset>
				<legend>ADD Details for Spents!!</legend>
				<table style="margin-bottom:10px">
				<tr><td style="width:180px"><label style="width:180px">Product Name :</label></td><td style="width:750px"><input style="font-size: 20px;width:770px;height: 30px;" type="text"  name="product_name" id="product"/></td><tr>
				<tr><td><label>Problem :</label></td><td><input style="font-size: 20px;width:770px;height: 30px;" type="text"  name="problem" id="brand"/></td><tr>
				<tr><td><label>Qty :</label></td><td><input size="4" style="font-size: 20px;width:50px;height: 30px;" type="text"  name="qty" id="brand"/></td><tr>
				<tr><td><label>Serial NO :</label></td><td><input style="font-size: 20px;width:250px;height: 30px;" type="text"  name="sn" id="brand"/></td><tr>
				<tr><td><label>Customer Info :</label></td><td><input style="font-size: 20px;width:770px;height: 30px;" type="text"  name="customer_info" id="brand"/></td><tr>
				<tr><td style="width:180px"><label style="width:180px">Send Media :</label></td><td style="width:750px"><input style="font-size: 20px;width:770px;height: 30px;" type="text"  name="send_media" id="product"/></td><tr>
				</table>
				
				<input style="cursor:pointer;color:red;width:100%;font-style:italic;font-size:30px" type="submit" name="add" value="ADD"/>
																		
			</fieldset>
		</form>
<?php 
}
require_once("footer.php");
?>
<script>
$(document).ready(function(){
	$(".hide,.hidding").hide();
	$(".showing").click(function(){
		$(".show").show();
		$(this).hide();
		$(".hidding").show();
		$("#proinfo").hide();
	})
	$(".hidding").click(function(){
		$(".show").hide();
		$(this).hide();
		$(".showing").show();
		$("#proinfo").show();
	})
})
</script>
