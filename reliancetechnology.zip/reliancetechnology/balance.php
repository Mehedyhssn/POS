<?php
require_once("connection.php");
require_once("header.php");
echo '<h1 style="text-align:center;margin-bottom:15px">Balance Page</h1>';
if(isset($_POST['add'])){
	
	if( empty($_POST['spent'])
		or empty($_POST['amount'])
	  
	){
		echo '<script>alert("fill all fields!!")</script>';
		echo '<script>window.location.href="http://localhost/reliancetechnology/balance.php"</script>';
	}else{
		$dated = mysql_query('SELECT curdate();');
		$date = mysql_fetch_assoc($dated);
		$curr_date = $date['curdate()'];
		mysql_query("insert into balance (`balance_ID`,`dated`,`spent`,`amount`) values ('','$curr_date','$_POST[spent]','$_POST[amount]')");	
		//Showing Tables of balance
		$dated = mysql_query('SELECT curdate();');
		$date = mysql_fetch_assoc($dated);
		$curr_date = $date['curdate()'];
		
      echo '<input type="button" class="showing" value="Show">
	  <input type="button" class="hidding" value="hide"><table class="show hide" style="margin-top:10px;text-align:center"><th colspan="2">Cash history</th>';
		       $total_sale_balance = mysql_fetch_array(mysql_query("select sum(grand_total) from daily_sale"));
			   $today_sale_balance= mysql_fetch_array(mysql_query("select sum(grand_total) from daily_sale where dated='$curr_date'"));
			   if($today_sale_balance['sum(grand_total)']==null){
				 $today_sale = 0;
			   }else{
				   $today_sale = $today_sale_balance['sum(grand_total)'];
			   }
			   $pre_balance = $total_sale_balance['sum(grand_total)'] - $today_sale;
			   
			   
			   
			   $total_spend_balance = mysql_fetch_array(mysql_query("select sum(amount) from balance"));
			   $today_spend_balance= mysql_fetch_array(mysql_query("select sum(amount) from balance where dated='$curr_date'"));
			   if($today_spend_balance['sum(amount)']==null){
				 $today_spend = 0;
			   }else{
				   $today_spend = $today_spend_balance['sum(amount)'];
			   }
			   $pre_spend_balance = $total_spend_balance['sum(amount)'] - $today_spend;
			   
			   $availabe_balance = $total_sale_balance['sum(grand_total)'] - $total_spend_balance['sum(amount)'];
			   
			   //$spend_balance = mysql_fetch_array(mysql_query("select sum(amount) from balance"));
			   //$balance = $pre_balance['sum(grand_total)'] - $spend_balance['sum(amount)'];
		       echo '<tr><td>Previous  Balance : </td><td>'.$pre_balance.'</td></tr>';
			   echo '<tr><td>Todays balance : </td><td>'.$today_sale.'</td></tr>';
			   echo '<tr><td>Total balance : </td><td>'.$total_sale_balance['sum(grand_total)'].'</td></tr>';
			   echo '<tr><th colspan="2">Todays Spend</th></tr>';
			   $today_spend_query = mysql_query("select * from balance where dated='$curr_date'");
			   $i=1;
			   while($r=mysql_fetch_array($today_spend_query)){
				    echo '<tr><td>'.$i. '. '.$r['spent'].'</td><td>'.$r['amount'].'</td></tr>';
					$i++;
			   }
			   echo '<tr><td>Todays Spend : </td><td>'.$today_spend.'</td></tr>';
			   echo '<tr><td>Available balance : </td><td>'.$availabe_balance.'</td></tr>';
			   
			   //echo '<tr><td>Available Cash :</td><td>'.$balance.'</td></tr>';
		echo '</table>';
		
	}
	
	
}else{
	    $dated = mysql_query('SELECT curdate();');
		$date = mysql_fetch_assoc($dated);
		$curr_date = $date['curdate()'];
		
      echo '<input type="button" class="showing" value="Show">
	  <input type="button" class="hidding" value="hide"><table class="show hide" style="margin-top:10px;text-align:center"><th colspan="2">Cash history</th>';
		       $total_sale_balance = mysql_fetch_array(mysql_query("select sum(grand_total) from daily_sale"));
			   $today_sale_balance= mysql_fetch_array(mysql_query("select sum(grand_total) from daily_sale where dated='$curr_date'"));
			   if($today_sale_balance['sum(grand_total)']==null){
				 $today_sale = 0;
			   }else{
				   $today_sale = $today_sale_balance['sum(grand_total)'];
			   }
			   $pre_balance = $total_sale_balance['sum(grand_total)'] - $today_sale;
			   
			   
			   
			   $total_spend_balance = mysql_fetch_array(mysql_query("select sum(amount) from balance"));
			   $today_spend_balance= mysql_fetch_array(mysql_query("select sum(amount) from balance where dated='$curr_date'"));
			   if($today_spend_balance['sum(amount)']==null){
				 $today_spend = 0;
			   }else{
				   $today_spend = $today_spend_balance['sum(amount)'];
			   }
			   $pre_spend_balance = $total_spend_balance['sum(amount)'] - $today_spend;
			   
			   $availabe_balance = $total_sale_balance['sum(grand_total)'] - $total_spend_balance['sum(amount)'];
			   
			   //$spend_balance = mysql_fetch_array(mysql_query("select sum(amount) from balance"));
			   //$balance = $pre_balance['sum(grand_total)'] - $spend_balance['sum(amount)'];
		       echo '<tr><td>Previous  Balance : </td><td>'.$pre_balance.'</td></tr>';
			   echo '<tr><td>Todays balance : </td><td>'.$today_sale.'</td></tr>';
			   echo '<tr><td>Total balance : </td><td>'.$total_sale_balance['sum(grand_total)'].'</td></tr>';
			   echo '<tr><th colspan="2">Todays Spend</th></tr>';
			   $today_spend_query = mysql_query("select * from balance where dated='$curr_date'");
			   $i=1;
			   while($r=mysql_fetch_array($today_spend_query)){
				    echo '<tr><td>'.$i. '. '.$r['spent'].'</td><td>'.$r['amount'].'</td></tr>';
					$i++;
			   }
			   echo '<tr><td>Todays Spend : </td><td>'.$today_spend.'</td></tr>';
			   echo '<tr><td>Available balance : </td><td>'.$availabe_balance.'</td></tr>';
			   
			   //echo '<tr><td>Available Cash :</td><td>'.$balance.'</td></tr>';
		echo '</table>';
?>

<form method="POST" action="balance.php" id="proinfo">
	<fieldset>
		<legend>ADD Details for Spents!!</legend>
		<table style="margin-bottom:10px">
		<tr><td style="width:180px"><label style="width:180px">Spents :</label></td><td style="width:750px"><input style="font-size: 20px;width:770px;height: 30px;" type="text"  name="spent" id="product"/></td><tr>
		<tr><td><label>Amount :</label></td><td><input style="font-size: 20px;width:770px;height: 30px;" type="text"  name="amount" id="brand"/></td><tr></table>
		
		<input style="cursor:pointer;color:red;width:100%;font-style:italic;font-size:30px" type="submit" name="add" value="ADD"/>
																
	</fieldset>
</form>
<?php 
}
require_once("footer.php");
?>
<script>
$(document).ready(function(){
	$(".hide,.hidding").hide();
	$(".showing").click(function(){
		$(".show").show();
		$(this).hide();
		$(".hidding").show();
		$("#proinfo").hide();
	})
	$(".hidding").click(function(){
		$(".show").hide();
		$(this).hide();
		$(".showing").show();
		$("#proinfo").show();
	})
})
</script>
