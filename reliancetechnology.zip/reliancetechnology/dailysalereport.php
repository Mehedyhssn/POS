<?php
require_once("connection.php");
require_once("header.php");
echo '<h1 style="text-align:center;margin-bottom:10px">Daily Sale Report</h1>';
?>
		<form style="margin-bottom:50px;width:60%;float:left" id="form1" name="form1" method="post" action="dailysalereport.php">
			<input type="text" name="search1" id="datepicker1" /> &nbsp;&nbsp; To &nbsp;&nbsp;<input type="text" name="search2" id="datepicker2" />
			<input type="submit" name="submit" value="Search" style="cursor:pointer" />
		</form>
		
		<div id="show_daily_sale_print">
			<?php 
				if(isset($_POST['submit'])){
					if($_POST['search1']=='' or $_POST['search2']==''){
						echo 'Please fill all input fields!';
					}else{
						$search1 = mysql_real_escape_string($_POST['search1']);
						$search2 = mysql_real_escape_string($_POST['search2']);
						echo '<form method="POST" action="export.php"><input type="hidden" name="search1" value="'.$search1.'"><input type="hidden" name="search2" value="'.$search2.'"><table name="print" border="1" id="res" style="border-collapse: collapse; text-align: center; width:100%;border: 0 none;">
						<th class="th">DATE</th><th class="th">PRODUCT NAME</th><th class="th">BRAND</th><th class="th">MODEL</th><th class="th">SL NO :</th><th class="th">WARRANTY</th><th class="th">QTY</th><th class="th">UNIT PRICE</th><th class="th">TOTAL SALE</th><th class="th">PROFIT</th>';
						$sql = mysql_query("SELECT dated FROM daily_sale WHERE `dated` BETWEEN '$search1' AND '$search2' GROUP BY dated HAVING COUNT(*)>=1 ");
						while($r=mysql_fetch_array($sql)){
							$dated = $r['dated'];
							$sql_1 = mysql_query("SELECT * FROM daily_sale WHERE dated='$dated'");
							$grand_total_sale = mysql_fetch_array(mysql_query("SELECT sum(grand_total),sum(grand_profit) FROM daily_sale WHERE dated='$dated'"));
							while($r_1=mysql_fetch_array($sql_1)){
								$profit = $r_1['grand_total'] - ($r_1['qty']*$r_1['buy_price']);
								echo '<tr><td>'.$r_1['dated'].'<input type="hidden" name="dated[]" value="'.$r_1['dated'].'"></td>
								          <td>'.$r_1['product'].'<input type="hidden" name="product[]" value="'.$r_1['product'].'"></td>
										  <td>'.$r_1['brand'].'<input type="hidden" name="brand[]" value="'.$r_1['brand'].'"></td>
										  <td>'.$r_1['model'].'<input type="hidden" name="model[]" value="'.$r_1['model'].'"></td>
										  <td class="sl">'.$r_1['sl'].'<input type="hidden" name="sl[]" value="'.$r_1['sl'].'"></td>
										  <td class="wnt">'.$r_1['wnty'].'<input type="hidden" name="wnty[]" value="'.$r_1['wnty'].'"></td>
										  <td>'.$r_1['qty'].'<input type="hidden" name="qty[]" value="'.$r_1['qty'].'"></td>
										  <td>'.$r_1['unit_price'].'<input type="hidden" name="unit_price[]" value="'.$r_1['unit_price'].'"></td>
										  <td>'.$r_1['grand_total'].'<input type="hidden" name="grand_total[]" value="'.$r_1['grand_total'].'"></td>
										  <td>'.$profit.'</td><input type="hidden" name="profit[]" value="'.$profit.'"></tr>';
							    
								
							}//END OF SECOND WHILE
							
							echo '<tr class="top_border"><td class="top_border"></td><td class="top_border"></td><td class="top_border"></td><td class="sl top_border"></td><td class="wnt top_border"></td><td class="top_border"></td><td class="top_border"></td><td class="top_border green">Daily Total</td><td class="top_border green">'.$grand_total_sale['sum(grand_total)'].'<input type="hidden" name="grand_total_sale[]" value="'.$grand_total_sale['sum(grand_total)'].'"></td><td class="top_border green">'.$grand_total_sale['sum(grand_profit)'].'<input type="hidden" name="grand_total_profit[]" value="'.$grand_total_sale['sum(grand_profit)'].'"></td></tr>';
							echo '<tr style="border:none"><td style="border:none">&nbsp;</td><td style="border:none">&nbsp;</td><td style="border:none">&nbsp;</td><td style="border:none"></td><tdstyle="border:none"></td><td style="border:none"></td><td style="border:none"></td><td style="border:none"></td><td style="border:none"></td><td style="border:none"></td></tr>';
							
							
								
								
							
								
								
							
						}// END OF FIRST WHILE 
						
						
							$sql_3= mysql_fetch_array(mysql_query("SELECT SUM(grand_total) FROM daily_sale WHERE `dated` BETWEEN '$search1' AND '$search2'"));
							$sql_4= mysql_fetch_array(mysql_query("SELECT SUM(grand_profit) FROM daily_sale WHERE `dated` BETWEEN '$search1' AND '$search2'"));
							
							echo '<tr style="border:none">
							<td style="border:none">&nbsp;</td><td style="border:none">&nbsp;</td><td style="border:none">&nbsp;</td>
							<td style="border:none">&nbsp;</td><td style="border:none">&nbsp;</td>
							<td style="border:none">&nbsp;</td><td style="border:none">&nbsp;</td>
							<td style="font-weight:bold;color:lightyellow;background:black;width:90px">Grand Total</td></td>
							<td style="font-weight:bold;color:lightyellow;background:red;">'.$sql_3['SUM(grand_total)'].'<input type="hidden" name="grand_total_sale_2" value="'.$sql_3['SUM(grand_total)'].'"></td>
							<td style="font-weight:bold;color:lightyellow;background:green;">'.$sql_4['SUM(grand_profit)'].'<input type="hidden" name="grand_total_profit_2" value="'.$sql_4['SUM(grand_profit)'].'"></td></tr>';
						echo '</table><input type="hidden" name="info"/><form>
						<br><br><input style="cursor:pointer;float:right;color:red;font-weight:bold;font-size:15px;font-style: italic;font-weight: bold;" type="submit" style="float:right;cursor:pointer" value="Export To PDF" />';
						 
						
					}//END OF SEARCH 1 AND 2 IF
				}//END OF SUBMIT IF
			?>
		</div>			
		
	</div>
</div>
		</div><!-- END CONTENT-->
  <?php
  require_once("footer.php ");
  ?>
<script>
	$(function() {
		$( "#datepicker1" ).datepicker({
		  
			dateFormat: 'yy-m-d',
			showOn: "button",
			buttonImage: "images/calendar.gif",
			buttonImageOnly: true,
			buttonText: "Select date",
			position: "relative"
		});
	});
	$(function() {
		$( "#datepicker2" ).datepicker({
		
			 dateFormat: 'yy-m-d',
			showOn: "button",
			buttonImage: "images/calendar.gif",
			buttonImageOnly: true,
			buttonText: "Select date"
		});
	});
</script>
<script language="javascript" type="text/javascript">
   /*  function PrintContent()
    {
		printWindow = window.open("", "mywindow", "location=0,status=0,scrollbars=1");
		printWindow.document.write("<html>");
		printWindow.document.write("<head>");
		printWindow.document.write('<link rel="stylesheet" type="text/css" href="daily_sale_print_css.css">');
		printWindow.document.write("</head>");
		printWindow.document.write("<body>");
		
        printWindow.document.write("<table><tr><img src='images/reliance.jpg' style='height: 140px; width:295px;margin:0 auto;' class='img'></tr></table><table id='tab' style='margin:0 auto;width:900px;'>");
        printWindow.document.write(document.getElementById('res').innerHTML);
		printWindow.document.write("</table>");
		printWindow.document.write("<input type='button' id='btnPrint' value='Print' style='width:100px' onclick='window.print()' />");
        printWindow.document.write("<input type='button' id='btnCancel' value='Cancel' style='width:100px' onclick='window.close()' />");
       	
		printWindow.document.write("</body");
		printWindow.document.write("</html>");
			
			
		printWindow.document.close();
        printWindow.focus();
    } */
</script>
