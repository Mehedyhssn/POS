<?php
$con = mysql_connect('localhost','root','');
$db = mysql_select_db('r_tech');
if(!$con){
	echo "Could not connect!".mysql_error();
}
if(!$db){
	echo "Could not connect!".mysql_error();
}
?>