<?php
require_once("connection.php");
require_once('header.php');
if(isset($_GET["Update"])){
	
		if( $_GET['net_outstanding'] == 0){
			echo 'This Customer all ready paid all dues!!';
			echo '<br><br><a href="http://localhost/reliancetechnology/sale.php">Go to customer sale page!!</a>';
		}else{
		$collection = $_GET['db_given_collection'] + $_GET['user_given_collection'];
		$net_outstanding = abs($_GET['net_outstanding']) - $_GET['user_given_collection'];
		$dated = mysql_query('SELECT curdate();');
		$date = mysql_fetch_assoc($dated);
		$curr_date = $date['curdate()'];
		mysql_query("INSERT INTO customer_sale_report (`customer_ID`, `dated`, 
													`grand_total`, `previous_deu`, 
													`collection`, `net_outstanding`)
										VALUES ('$_GET[customer_ID]','$curr_date',
												'$_GET[grand_total]','$_GET[db_previous_deu]','$collection','$net_outstanding')");
												
												
		echo '<form method="POST" action="export.php"><table style="margin-bottom:10px">';
			 $q = mysql_query("select * from customer where customer_ID='$_GET[customer_ID]'");
			 while($r = mysql_fetch_array($q)){
				 echo '<th class="th">Customer Name : '.$r['name'].'</th><th class="th">Address : '.$r['address'].'</th><th class="th">Mobile : '.$r['mobile'].'<input type="hidden" name="mobile" value="'.$r['mobile'].'"></th>';
			 }
			 $q_update = mysql_query("select * from customer_sale_report where customer_ID='$_GET[customer_ID]' order by cust_sale_rep desc limit 0,1");
			 while($r = mysql_fetch_array($q_update)){
				 echo '<tr><td>Date : </td><td colspan="2">'.$r['dated'].'</td></tr>
				 <tr><td>Previous Grand Total : </td><td colspan="2">'.$r['grand_total'].'</td></tr>
				 <tr><td>Previous Dues : </td><td colspan="2">'.$r['previous_deu'].'</td></tr>
				 <tr><td>Collection : </td><td colspan="2">'.$r['collection'].'</td></tr>
				 <tr><td>Net Outstanding : </td><td colspan="2">'.$r['net_outstanding'].'</td></tr>';
			 }
		echo '</table><input style="cursor:pointer;color:red;font-weight:bold;font-size:15px" name="update_customer_dues" type="submit" value="Export to PDF"></form>';	
		}
	    
}
require_once('footer.php');
?>