<?php
require_once("connection.php");
if( isset($_POST['info']) ){
		require_once("fpdf/fpdf.php");
		$pdf = new FPDF();
		$pdf->Addpage();
		$pdf->SetFont('Arial','B',10);
		$pdf->Multicell(0,8,$pdf->Image("images/reliance.jpg",10,7,-600)."Shop No#16 (Ground Floor), Press Club Market, Rangpur.\n Mobile No# 01784041111,01737091505","B",0);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(20,7,"Date ",1,0,"C");
		$pdf->Cell(80,7,"Products Details",1,0,"C");
		$pdf->Cell(10,7,"Qty.",1,0,"C");
		$pdf->Cell(20,7,"Unit Price",1,0,"C");
		$pdf->Cell(30,7,"Total Sale",1,0,"C");
		$pdf->Cell(30,7,"Total Profit",1,1,"C");
		$sql = mysql_query("SELECT * FROM daily_sale,sl WHERE `dated` BETWEEN '$_POST[search1]' AND '$_POST[search2]' GROUP BY dated HAVING COUNT(*)>=1 ");
						while($r=mysql_fetch_array($sql)){
							$dated = $r['dated'];
							$sql_1 = mysql_query("SELECT * FROM daily_sale WHERE dated='$dated'");
							$grand_total_sale = mysql_fetch_array(mysql_query("SELECT sum(grand_total),sum(grand_profit) FROM daily_sale WHERE dated='$dated'"));
							while($r_1=mysql_fetch_array($sql_1)){
								$profit = $r_1['grand_total'] - ($r_1['qty']*$r_1['buy_price']);
								
								$pdf->SetFont("Helvetica","",10);
								$total = $r['qty'] * $r['unit_price'];
								// Arial bold 14
								$pdf->SetFont('Arial','I',8);
								$pdf->Cell(20,8,"".$r_1['dated']."",0,0,"C");
								$pdf->SetFont('Arial','B',9);
								$pdf->Cell(80,5,"".$r_1['product']." ".$r_1['brand']." ".$r_1['model']."",0,0);
								$pdf->SetFont('Arial','I',8);
								$pdf->Cell(10,8,"".$r_1['qty']."",0,0,"C");
								$pdf->Cell(20,7,"".$r_1['unit_price']."",0,0,"C");
								$pdf->Cell(30,7,"".$r_1['grand_total']."",0,0,"C");
								$pdf->Cell(30,7,"".$profit."",0,1,"C");
								$pdf->Cell(20,8,"",0,0,"C");
								$pdf->Cell(80,4,"S/N ".$r_1['sl']." WARRANTY ".$r_1['wnty']."",0,1,"T");
								
								
								
							}
							$pdf->SetFont('Arial','B',8);
							$pdf->Cell(190,8,"Total : ".$grand_total_sale['sum(grand_total)']."     profit: ".$grand_total_sale['sum(grand_profit)']."","T",1,"R");
							$pdf->Cell(190,8,"","",1,"");
							
			
						}
						$sql_3= mysql_fetch_array(mysql_query("SELECT SUM(grand_total) FROM daily_sale WHERE `dated` BETWEEN '$_POST[search1]' AND '$_POST[search2]'"));
						$sql_4= mysql_fetch_array(mysql_query("SELECT SUM(grand_profit) FROM daily_sale WHERE `dated` BETWEEN '$_POST[search1]' AND '$_POST[search2]'"));
						$pdf->SetFont('Arial','B',8);
						$pdf->Cell(190,8,"","",1,"");
						$pdf->Cell(190,8,"","",1,"");
						$pdf->Cell(190,8,"Grand Total : ".$sql_3['SUM(grand_total)']."     Grand profit: ".$sql_4['SUM(grand_profit)']."","T",0,"R");
		$pdf->output();
						
}else if(isset($_POST['buyinfo'])){
		require_once("fpdf/fpdf.php");
		$pdf = new FPDF();
		$pdf->Addpage();
		$pdf->SetFont('Arial','B',10);
		$pdf->Multicell(0,8,$pdf->Image("images/reliance.jpg",10,7,-600)."Shop No#16 (Ground Floor), Press Club Market, Rangpur.\n Mobile No# 01784041111,01737091505","B",0);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(20,7,"Date ",1,0,"C");
		$pdf->Cell(100,7,"Products Details",1,0,"C");
		$pdf->Cell(10,7,"Qty.",1,0,"C");
		$pdf->Cell(35,7,"Unit Price",1,0,"C");
		$pdf->Cell(35,7,"Total Buy",1,1,"C");
		$sql = mysql_query("SELECT * FROM daily_buy,sl WHERE `dated` BETWEEN '$_POST[search1]' AND '$_POST[search2]' GROUP BY dated HAVING COUNT(*)>=1 ");
						while($r=mysql_fetch_array($sql)){
							$dated = $r['dated'];
							$sql_1 = mysql_query("SELECT * FROM daily_buy WHERE dated='$dated'");
							$grand_total_buy = mysql_fetch_array(mysql_query("SELECT sum(total) FROM daily_buy WHERE dated='$dated'"));
							
							while($r_1=mysql_fetch_array($sql_1)){
								
							$pdf->SetFont("Helvetica","",10);
							$total = $r['qty'] * $r['unit_price'];
							// Arial bold 14
							$pdf->SetFont('Arial','I',8);
							$pdf->Cell(20,8,"".$dated."",0,0,"C");
							$pdf->SetFont('Arial','B',8);
							$pdf->Cell(100,7,"".$r['product']." ".$r['brand']." ".$r['model']."",0,0,"B");
							$pdf->SetFont('Arial','I',8);
							$pdf->Cell(10,8,"".$r['qty']."",0,0,"C");
							$pdf->Cell(37,7,"".$r['unit_price']."",0,0,"C");
							$pdf->Cell(35,7,"".$total."",0,1,"C");
							$pdf->Cell(20,8,"",0,0,"C");
							$sl_query = mysql_query("select si_no from sl where daily_buy_id='$r_1[dailybuy_ID]'");
							while($r_2=mysql_fetch_array($sl_query)){
							$pdf->Cell(100,5,"S/N ".$r_2['si_no']." WARRANTY ".$r['wnty']."",0,1);	
							}
							
		                    }
							$pdf->Cell(190,0,"","T",1);
							$pdf->SetFont('Arial','B',8);
							$pdf->Cell(190,6,"Daily Total ".$grand_total_buy['sum(total)']."",0,1,"R");
						}
						$pdf->Ln();
						$pdf->Ln();
		                $sql_3= mysql_fetch_array(mysql_query("SELECT SUM(total) FROM daily_buy WHERE `dated` BETWEEN '$_POST[search1]' AND '$_POST[search2]'"));
						$pdf->SetFont('Arial','B',8);
						$pdf->Cell(190,6,"Grand Total : ".$sql_3['SUM(total)']."","T",0,"R");
			
			
		
		$pdf->output();
			
}else if(isset($_POST['customer_sale_report'])){
	    require_once("fpdf/fpdf.php");
		$pdf = new FPDF();
		$pdf->Addpage();
		$pdf->SetFont("Arial","",10);
		$pdf->Multicell(0,8,$pdf->Image("images/reliance.jpg",10,7,-600)."Shop No#16 (Ground Floor), Press Club Market, Rangpur.\n Mobile No# 01784041111,01737091505","B",0);
		$customer_query = mysql_query("select * from customer where customer_ID='$_POST[customer_id]'");
		while($r=mysql_fetch_array($customer_query)){
			$pdf->SetFont("Arial","B",10);
			$pdf->Cell(190,6,"Invoice/Bill",0,1,"C");
			$pdf->SetFont("Arial","I",10);
			$pdf->Cell(90,5,"Customer Name :".$r['name'],0,0,"C"); 
			$pdf->Cell(50,5,"Address  :".$r['address'],0,0,"C");
			$pdf->Cell(50,5,"Sold By  :".$_POST['sold_by'],0,0,"C");
			$pdf->Ln();
			$pdf->Cell(80,5,"Contact No :".$r['mobile'],0,"R",0); 
			$pdf->Cell(40,5,"Order No  :".$_POST['order_no'],0,0,"C");
			$pdf->Cell(80,5,"Date  :".$_POST['curdate'],0,0,"L");
			$pdf->Ln();
			
		 }
		$pdf->SetFont("Helvetica","",10);
		$total = $r['qty'] * $r['unit_price'];
		// Arial bold 14
		$pdf->SetFont('Arial','B',10);
		$pdf->Ln();
		$pdf->Cell(10,7,"No. ",1,0,"C");
		$pdf->Cell(100,7,"Products Details",1,0,"C");
		$pdf->Cell(10,7,"Qty.",1,0,"C");
		$pdf->Cell(35,7,"Unit Price",1,0,"C");
		$pdf->Cell(35,7,"Total",1,1,"C");
		$i = 1;
		$q = mysql_query("select * from daily_sale where customer_ID='$_POST[customer_id]' and dated='$_POST[curdate]' and order_no='$_POST[order_no]'");
		while($r=mysql_fetch_array($q)){
			$pdf->SetFont("Helvetica","",10);
			$total = $r['qty'] * $r['unit_price'];
			// Arial bold 14
			$pdf->SetFont('Arial','I',8);
			$pdf->Cell(10,8,"".$i."",0,0,"C");
			$pdf->SetFont('Arial','B',8);
			$pdf->Cell(100,5,"".$r['product']." ".$r['brand']." ".$r['model']."",0,0);
			$pdf->SetFont('Arial','I',8);
			$pdf->Cell(10,8,"".$r['qty']."",0,0,"C");
			$pdf->Cell(37,7,"".$r['unit_price']."",0,0,"C");
			$pdf->Cell(35,7,"".$total."",0,1,"C");
			$pdf->Cell(10,8,"",0,0,"C");
			$pdf->Cell(100,5,"S/N ".$r['sl']." WARRANTY ".$r['wnty']."",0,1);
			
			
			$i++;
		}
		
		$pdf->Cell(160,6,"","T",0,"R");
		$pdf->Cell(30,6,"","T",1,"R");
		$q2 = mysql_query("select sum(grand_total) from daily_sale where customer_ID='$_POST[customer_id]' and dated='$_POST[curdate]' and order_no='$_POST[order_no]'");
		while($r=mysql_fetch_array($q2)){
			$pdf->SetFont('Arial','B',8);
			$pdf->Cell(190,6,"Grand Total: ".$r['sum(grand_total)']."",0,1,"R");
		}
		$pdf->SetFont('Arial','I',8);
		$pdf->Cell(190,6,"Previous Dues: ".$_POST['pre_due']."",0,1,"R");
		$pdf->Cell(190,6,"Collections: ".$_POST['collection']."",0,1,"R");
		$pdf->Cell(190,6,"Net Outstandings: ".$_POST['net_out']."",0,1,"R");
		$pdf->Ln();
		
		$pdf->Cell(190,6,"Signature & Company Stamp                                                                                                                                  Authorised signature & Company Stamp ",0,1);
		$pdf->Ln();
		$pdf->Ln();		
		$pdf->Cell(190,6,"** WARRANTY WILL BE GONE IF ANY STICKER OF PRODUCT REMOVED ",0,1,"L");
		
		
		$pdf->output();
		
	   	
}else if(isset($_POST['update_customer_dues'])){
	require_once("fpdf/fpdf.php");
		$pdf = new FPDF();
		$pdf->Addpage();
		$pdf->SetFont("Arial","",10);
		$pdf->Multicell(0,8,$pdf->Image("images/reliance.jpg",10,7,-600)."Shop No#16 (Ground Floor), Press Club Market, Rangpur.\n Mobile No# 01784041111,01737091505","B",0);
		$q = mysql_query("select * from customer where mobile='$_POST[mobile]'");
			 while($r = mysql_fetch_array($q)){
				 $pdf->Ln();
				 $pdf->SetFont("Arial","B",10);
				 $pdf->Cell(65,7,"Customer Name : ".$r['name']."",0,0,"C");
				 $pdf->Cell(65,7,"Address : ".$r['address']."",0,0,"C");
				 $pdf->Cell(65,7,"Mobile : ".$r['mobile']."",0,1,"C");
				 $pdf->Ln();
				 $pdf->Ln();
				 $q_update = mysql_query("select * from customer_sale_report where customer_ID='$r[customer_ID]' order by cust_sale_rep desc limit 0,1");
				 while($r2 = mysql_fetch_array($q_update)){
					 $pdf->SetFont("Arial","I",10);
					 $pdf->Cell(65,7,"",0,0,"C");
					 $pdf->Cell(65,7,"Paid Date : ".$r2['dated']."","TRL",1,"C");
					 $pdf->Cell(65,7,"",0,0,"C");
					 $pdf->Cell(65,7,"Grand Total : ".$r2['grand_total']."","LR",1,"C");
					 $pdf->Cell(65,7,"",0,0,"C");
					 $pdf->Cell(65,7,"Previous Dues : ".$r2['previous_deu']."","LR",1,"C");
					 $pdf->Cell(65,7,"",0,0,"C");
					 $pdf->Cell(65,7,"Collection : ".$r2['collection']."","LR",1,"C");
					 $pdf->Cell(65,7,"",0,0,"C");
					 $pdf->Cell(65,7,"Net Outstandings : ".$r2['net_outstanding']."","BRL",1,"C");
				    }
			    }
		$pdf->Ln();
		$pdf->Ln();
		$pdf->Ln();
		$pdf->Ln();
		$pdf->Ln();
		$pdf->Ln();
		$pdf->SetFont("Arial","I",8);
		$pdf->Cell(190,6,"Signature & Company Stamp                                                                                                                             Authorised signature & Company Stamp ",0,1);	 
		$pdf->output();	
}else if(isset($_POST['balance'])){
	    require_once("fpdf/fpdf.php");
		$pdf = new FPDF();
		$pdf->Addpage();
		$pdf->SetFont("Arial","",10);
		$pdf->Multicell(0,8,$pdf->Image("images/reliance.jpg",10,7,-600)."Shop No#16 (Ground Floor), Press Club Market, Rangpur.\n Mobile No# 01784041111,01737091505","B",0);
		$q = mysql_query("select * from customer where mobile='$_POST[mobile]'");
			 while($r = mysql_fetch_array($q)){
				 $pdf->Ln();
				 $pdf->SetFont("Arial","B",10);
				 $pdf->Cell(65,7,"Customer Name : ".$r['name']."",0,0,"C");
				 $pdf->Cell(65,7,"Address : ".$r['address']."",0,0,"C");
				 $pdf->Cell(65,7,"Mobile : ".$r['mobile']."",0,1,"C");
				 $pdf->Ln();
				 $pdf->Ln();
				 $q_update = mysql_query("select * from customer_sale_report where customer_ID='$r[customer_ID]' order by cust_sale_rep desc limit 0,1");
				 while($r2 = mysql_fetch_array($q_update)){
					 $pdf->SetFont("Arial","I",10);
					 $pdf->Cell(65,7,"",0,0,"C");
					 $pdf->Cell(65,7,"Paid Date : ".$r2['dated']."","TRL",1,"C");
					 $pdf->Cell(65,7,"",0,0,"C");
					 $pdf->Cell(65,7,"Grand Total : ".$r2['grand_total']."","LR",1,"C");
					 $pdf->Cell(65,7,"",0,0,"C");
					 $pdf->Cell(65,7,"Previous Dues : ".$r2['previous_deu']."","LR",1,"C");
					 $pdf->Cell(65,7,"",0,0,"C");
					 $pdf->Cell(65,7,"Collection : ".$r2['collection']."","LR",1,"C");
					 $pdf->Cell(65,7,"",0,0,"C");
					 $pdf->Cell(65,7,"Net Outstandings : ".$r2['net_outstanding']."","BRL",1,"C");
				    }
			    }
		$pdf->Ln();
		$pdf->Ln();
		$pdf->Ln();
		$pdf->Ln();
		$pdf->Ln();
		$pdf->Ln();
		$pdf->SetFont("Arial","I",8);
		$pdf->Cell(190,6,"Signature & Company Stamp                                                                                                                             Authorised signature & Company Stamp ",0,1);	 
		$pdf->output();	
}
?>