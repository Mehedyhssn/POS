<?php
require_once("connection.php");
if(isset($_GET['dailySaleUpdateid'])){
	$grand_total = $_GET['qty'] * $_GET['unit_price'];
	mysql_query("update daily_sale set qty='$_GET[qty]', unit_price='$_GET[unit_price]', grand_total='$grand_total' where dailysale_ID='$_GET[dailySaleUpdateid]'");
		
}
if(isset($_GET['delete_id'])){
	mysql_query("delete from daily_sale where dailysale_ID='$_GET[delete_id]'");
}
?>