<?php
echo '</div><footer>
COPYRIGHT &copy '.date("Y").' reliancetechnology.com All rights reserved.
</footer>';
?>