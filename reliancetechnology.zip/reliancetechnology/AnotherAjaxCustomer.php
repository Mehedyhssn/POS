<?php
require_once('connection.php');
if(isset($_GET['dailysale_ID'])){
	mysql_query("update `daily_sale` set qty='$_GET[qty]', sale_price='$_GET[sale_price]', total='$_GET[total]' where  dailysale_ID='$_GET[dailysale_ID]'");
exit();
}
?>