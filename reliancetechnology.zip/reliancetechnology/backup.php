<?php
require_once("connection.php");
require_once("header.php");
echo '<h1 style="text-align:center">Backup Page</h1>';
?>
<form method="POST" action="export_import.php" style="float:left;width:50%;height:10%;margin:5px;">
<input type="submit" value="Export" name="export">
</form>
<form method="POST" action="import.php" style="flaot:right;width:50%;height:10%;margin:5px;">
<input type="file" name="sql_file">
<input type="submit" value="Import" name="import">
</form>
<?php
require_once("footer.php");
?>