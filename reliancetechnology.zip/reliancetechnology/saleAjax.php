<?php
require_once('connection.php');
//Reciving customer name
if(isset($_GET['mobile'])){
		$mobile = $_GET['mobile'];
		$query = mysql_query("SELECT * FROM `customer` WHERE mobile='$mobile'");
		
		while($rows = mysql_fetch_array($query)){
			echo '<td style="border-top:0;border-right:0;">Customer Name : '.$rows['name'].'</td><td style="border-top:0;border-right:0;">Address : '.$rows['address'].'</td><td>Sold By : <input type="text" autocomplete="off" class="sold_by" name="sold_by"/></td>
		';
		}
		

}
if(isset($_GET['customer_id'])){
		$mobile = $_GET['customer_id'];
		$query = mysql_query("SELECT * FROM `customer` WHERE mobile='$mobile'");
		
		while($rows = mysql_fetch_array($query)){
			echo $rows['customer_ID'];
		}
		

}

//Reciving customer address and name
/* if(isset($_GET['address'])){
		$customer = $_GET['customer'];
		$address = $_GET['address'];
		$query = mysql_query("SELECT * FROM `customer` WHERE customer_id='$customer' and address='$address'");
		
		while($rows = mysql_fetch_array($query)){
			echo $rows['mobile'].'<input type="hidden" class="mob" value="'.$rows['mobile'].'" name="mobile"/>';
		}
	
} */
//Reciving product data
if(isset($_GET['product'])){
	$product = $_GET['product'];
	$query = mysql_query("SELECT * FROM `daily_buy` WHERE product='$product' GROUP BY brand HAVING COUNT(*)>=1");
	echo '<select><option value="0" selected>---</option>';
	while($rows = mysql_fetch_array($query)){
		echo '<option value="'.$rows['brand'].'">'.$rows['brand'].'</option>';
	}
	echo '</select>';

}
//Reciving the brand data
if(isset($_GET['brand'])){
	$brand = $_GET['brand'];
	$product = $_GET['product'];
	$query = mysql_query("SELECT * FROM `daily_buy` WHERE product='$product' and brand='$brand' GROUP BY model HAVING COUNT(*)>=1");
	echo '<select><option value="0" selected>---</option>';
	while($rows = mysql_fetch_array($query)){
		echo '<option value="'.$rows['model'].'">'.$rows['model'].'</option>';
	}
	echo '</select>';

}
//Reciving the model data
if(isset($_GET['model'])){
	$model = mysql_real_escape_string($_GET['model']);
	$product = $_GET['product'];
	$brand = $_GET['brand'];
	$query = mysql_query("SELECT * FROM `daily_buy` WHERE product='$product' and brand='$brand' and model='$model'");
	echo '<select multiple>';
	while($rows = mysql_fetch_array($query)){
		echo $rows['dailybuy_ID'];
		$q2 = mysql_query("select * from sl where daily_buy_id='$rows[dailybuy_ID]' and status='on'");
		while($r=mysql_fetch_array($q2)){
			echo '<option value="'.htmlentities($r['si_no']).'">'.$r['si_no'].'</option>';
		}
	}
	echo '</select>';

}

//Reciving the sl data
if(isset($_GET['sl'])){
	$sl = $_GET['sl'];
	$product = $_GET['product'];
	$brand = $_GET['brand'];
	$model = $_GET['model'];
	$query = mysql_query("SELECT * FROM `daily_buy` WHERE product='$product' and brand='$brand' and model='$model' GROUP BY wnty HAVING COUNT(*) >= 1");
	echo '<select><option value="0" selected>---</option>';
	while($rows = mysql_fetch_array($query)){
		echo '<option value="'.$rows['wnty'].'">'.$rows['wnty'].'</option>';
	}
	echo '</select>';

}
//Reciving the wnty data
if(isset($_GET['wnty'])){
	$wnty = $_GET['wnty'];
	$product = $_GET['product'];
	$brand = $_GET['brand'];
	$model = $_GET['model'];
	$sl = $_GET['sl'];
	$query = mysql_query("SELECT * FROM `daily_buy` WHERE product='$product' and brand='$brand' and model='$model' and wnty='$wnty' HAVING COUNT(*) >= 1");
	echo '<select><option value="0" selected>---</option>';
	while($rows = mysql_fetch_array($query)){
		echo '<option>'.$rows['unit_price'].'('.$rows['dated'].')</option>';
	}
	echo '</select>';

}

///////////////////////////////////////////////////////////////////////
/////  Now inserting all data into daily sale table without customer details
//////////////////////////////////////////////////////////////////////
if(isset($_GET['customer_id'])){
	
	$customer_id = $_GET['customer_id'];
	$order_no = $_GET['order_no'];
	$sold_by = $_GET['sold_by'];
	$current_dated = $_GET['current_dated'];
	$product = $_GET['product'];
	$brand = $_GET['brand'];
	$model = $_GET['model'];
	$sl = substr($_GET['sl'], 0, -1);
	$bp = substr($_GET['bp'],0,-12);
    $wnty = $_GET['wnty'];
	$stokqty = $_GET['stokqty'];
	$sp = $_GET['sp'];
	$grand_total = $_GET['grand_total'];
    $grand_profit = $grand_total - ($stokqty*$bp);	
	mysql_query("INSERT INTO `daily_sale`(`dailysale_ID`, `customer_ID`, `order_no`, `sold_by`, `dated`, `product`, `brand`, `model`, `sl`, `wnty`, `qty`, `buy_price`,`unit_price`,`grand_total`,`grand_profit`) VALUES ('','$customer_id','$order_no','$sold_by','$current_dated','$product','$brand','$model','$sl','$wnty','$stokqty','$bp','$sp','$grand_total','$grand_profit')");
	
	$sl_array = explode(',', $sl);
	foreach($sl_array as $value){
		
			if($value=='0'){
				
			}else{
				mysql_query("update sl set status='off' where si_no='".mysql_real_escape_string($value)."'");
			}
		
		
	}
}


?>