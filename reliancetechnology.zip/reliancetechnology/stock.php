<?php
require_once('connection.php');
require_once('header.php');
echo '<h1 style="text-align:center;margin-bottom:15px">Stock</h1>';
//Starting Stock Management
if(isset($_GET['product'])){
	echo '<button style="margin-bottom:15px;font-weight:bold;color:red;font-style:italic;font-size:20px;cursor:pointer" onclick="window.history.go(-1)">Go Back </button><table style="width:960px; text-align:center;border-collapse: collapse;"><tr class="th"><th style="background:lightgray">'.$_GET['product'].'</th></tr></table><table style="text-align: center;
    width: 100%;"><th class="grey">Brand</th><th class="grey">Model</th><th class="grey">Total</th><th class="grey">Sold</th><th class="grey">In Stock</th><th class="grey">Total Buy</th><th class="grey">Total Buy-Sell</th><th class="grey">Total Stock Price</th>';
		$query = mysql_query("select * from daily_buy where product='$_GET[product]' group by brand,model having count(*) >=1");
				while($r = mysql_fetch_array($query)){
					echo '<tr>
							  <td>'.$r['brand'].'</td><td>'.$r['model'].'</td>';
							  //This is total section
							  echo '<td>';
							  $total = mysql_query("select sum(qty) from daily_buy where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
							  while($t = mysql_fetch_array($total)){
								  echo $t['sum(qty)'];
							  }
							  echo '</td>';
							  //End total section 
							  //This is Sold section
							  echo '<td>';
							  $sold = mysql_query("select sum(qty) from daily_sale where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
							  while($s = mysql_fetch_array($sold)){
								  echo $s['sum(qty)'];
							  }
							  echo '</td>';
							  //End Sold section 
							  echo '<td>';
								$buy_qty_query = mysql_query("select sum(qty) from daily_buy where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
								$sale_qty_query = mysql_query("select sum(qty) from daily_sale where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
								if(mysql_num_rows($sale_qty_query)==''){
									echo $r['qty'];
								}else{
									while($sr = mysql_fetch_array($sale_qty_query)){
										while($br = mysql_fetch_array($buy_qty_query)){
											echo $stock_qty = $br['sum(qty)'] - $sr['sum(qty)'];
											
										}
									}
								}
							  echo '</td>';
							  echo '<td>';
							  $daily_buy_total_buy_query = mysql_query("select sum(total) from daily_buy where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
							  while($dbtq = mysql_fetch_array($daily_buy_total_buy_query)){
								  echo number_format($dbtq['sum(total)'],2);
							  } 
							  echo '</td>';
							  echo '<td>';
							  $daily_sale_total_query = mysql_query("select * from daily_sale where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
							  if(mysql_num_rows($daily_sale_total_query)==null){
									  echo '0';
							  }else{
									$daily_sale_total_qty_query = mysql_query("select sum(qty) from daily_sale where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
									while($rtq = mysql_fetch_array($daily_sale_total_qty_query)){
										$daily_buy_total_buy_query = mysql_query("select sum(total),sum(qty) from daily_buy where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
										  while($dbtq = mysql_fetch_array($daily_buy_total_buy_query)){
											  $unit_price_for_sale = $dbtq['sum(total)'] / $dbtq['sum(qty)'];
											  $final_price = $unit_price_for_sale * $rtq['sum(qty)'];
											  echo number_format($final_price,2);
										  } 
									}
							  }							  
							  echo '</td>';
							  echo '<td>';
							   $daily_sale_total_query2 = mysql_query("select * from daily_sale where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
							  if(mysql_num_rows($daily_sale_total_query2)==null){
									  $a = mysql_fetch_array(mysql_query("select sum(total),sum(qty) from daily_buy where product='$r[product]' and brand='$r[brand]' and model='$r[model]'"));
									  echo $b = $a['sum(total)'];
							  }else{
										$buy_qty_query2 = mysql_query("select sum(qty),sum(total) from daily_buy where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
										$sale_qty_query2 = mysql_query("select sum(qty) from daily_sale where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
										while($sr = mysql_fetch_array($sale_qty_query2)){
											while($br = mysql_fetch_array($buy_qty_query2)){
												$stock_qty2 = $br['sum(qty)'] - $sr['sum(qty)'];
												$unit_price_for_sale2 = $br['sum(total)'] / $br['sum(qty)'];
											    $final_price_2 = $unit_price_for_sale2 * $stock_qty2;
												echo number_format($final_price_2,2);
											}
										}
										
									
							  }	
								
							  echo '</td>';
						  echo '</tr>';	
				}
				///// THIS IS FOR GRAND TOTAL
				echo '<th></th><th></th><th style="border-top:1px solid black">';
							  $total = mysql_query("select sum(qty) from daily_buy where product='$_GET[product]'");
							  while($t = mysql_fetch_array($total)){
								  echo $t['sum(qty)'];
							  }
							  echo '</th>';
							  //End total section 
							  //This is Sold section
							  echo '<th style="border-top:1px solid black">';
							  $sold = mysql_query("select sum(qty) from daily_sale where product='$_GET[product]'");
							  while($s = mysql_fetch_array($sold)){
								  echo $s['sum(qty)'];
							  }
							  echo '</th>';
							  //End Sold section 
							  echo '<th style="border-top:1px solid black">';
								$buy_qty_query = mysql_query("select sum(qty) from daily_buy where product='$_GET[product]'");
								$sale_qty_query = mysql_query("select sum(qty) from daily_sale where product='$_GET[product]'");
								if(mysql_num_rows($sale_qty_query)==''){
									echo $r['qty'];
								}else{
									while($sr = mysql_fetch_array($sale_qty_query)){
										while($br = mysql_fetch_array($buy_qty_query)){
											echo $stock_qty = $br['sum(qty)'] - $sr['sum(qty)'];
											
										}
									}
								}
							  echo '</th>';
							  echo '<th style="border-top:1px solid black">';
							  $daily_buy_total_buy_query = mysql_query("select sum(total) from daily_buy where product='$_GET[product]'");
							  while($dbtq = mysql_fetch_array($daily_buy_total_buy_query)){
								  echo number_format($dbtq['sum(total)'],2);
							  } 
							  echo '</th>';
							  echo '<th style="border-top:1px solid black">';
							  $daily_sale_total_query = mysql_query("select * from daily_sale where product='$_GET[product]'");
							  if(mysql_num_rows($daily_sale_total_query)==null){
									  echo '0';
							  }else{
								   $query = mysql_query("select * from daily_buy where product='$_GET[product]' group by brand,model having count(*) >=1");
									while($r = mysql_fetch_array($query)){
											$daily_sale_total_qty_query = mysql_query("select sum(qty) from daily_sale where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
											while($rtq = mysql_fetch_array($daily_sale_total_qty_query)){
												$daily_buy_total_buy_query = mysql_query("select sum(total),sum(qty) from daily_buy where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
												  while($dbtq = mysql_fetch_array($daily_buy_total_buy_query)){
													  $unit_price_for_sale = $dbtq['sum(total)'] / $dbtq['sum(qty)'];
													  $final_price_6= $unit_price_for_sale * $rtq['sum(qty)'];
													  $array = array('a'=>$final_price_6);
																foreach($array as $num => $values) {
																
																	$vatAmount6[] = $values;
																}
												  } 
											}
											
									}
									$Total6 = array_sum($vatAmount6);
									echo $final_price_6 = number_format($Total6,2);
							  }							  
							  echo '</th>';
							  echo '<th style="border-top:1px solid black">';
							   $daily_sale_total_query2 = mysql_query("select * from daily_sale where product='$_GET[product]'");
							  if(mysql_num_rows($daily_sale_total_query2)==null){
									  $a = mysql_fetch_array(mysql_query("select sum(total),sum(qty) from daily_buy where product='$_GET[product]'"));
									  echo $b = $a['sum(total)'];
							  }else{
									$query = mysql_query("select * from daily_buy where product='$_GET[product]' group by brand,model having count(*) >=1");
									while($r = mysql_fetch_array($query)){
										$buy_qty_query3 = mysql_query("select sum(qty),sum(total) from daily_buy where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
										$sale_qty_query3 = mysql_query("select sum(qty) from daily_sale where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
										while($sr3 = mysql_fetch_array($sale_qty_query3)){
											while($br3 = mysql_fetch_array($buy_qty_query3)){
												$stock_qty3 = $br3['sum(qty)'] - $sr3['sum(qty)'];
												$unit_price_for_sale3 = $br3['sum(total)'] / $br3['sum(qty)'];
											    $final_price_3 = $unit_price_for_sale3 * $stock_qty3;
											    $array = array('a'=>$final_price_3);
														foreach($array as $num => $values) {
														
															$vatAmount3[] = $values;
														}
											}
										}
										
							        }
									$Total = array_sum($vatAmount3);
									echo $final_price_3 = number_format($Total,2);
							  }	
								
							  echo '</th>';
				
echo '</table>';

}else{

		echo '<table style="width:100%;text-align:center"><th class="grey">Product Name</th><th class="grey">Total</th><th class="grey">Sold</th><th class="grey">In Stock</th><th class="grey">Total Buy</th><th class="grey">Total Buy-Sell</th><th class="grey">Total Stock Price</th>';
				$query = mysql_query("select * from daily_buy group by product having count(product) >=1");
				while($r = mysql_fetch_array($query)){
					echo '<tr>
							  <td><a href="stock.php?product='.$r['product'].'&brand='.$r['brand'].'">'.$r['product'].'</a></td>';
							  //This is total section
							  echo '<td>';
							  $total = mysql_query("select sum(qty) from daily_buy where product='$r[product]'");
							  while($t = mysql_fetch_array($total)){
								  echo $t['sum(qty)'];
							  }
							  echo '</td>';
							  //End total section 
							  //This is Sold section
							  echo '<td>';
							  $sold = mysql_query("select sum(qty) from daily_sale where product='$r[product]'");
							  while($s = mysql_fetch_array($sold)){
								  echo $s['sum(qty)'];
							  }
							  echo '</td>';
							  //End Sold section 
							  echo '<td>';
								$buy_qty_query = mysql_query("select sum(qty) from daily_buy where product='$r[product]'");
								$sale_qty_query = mysql_query("select sum(qty) from daily_sale where product='$r[product]'");
								if(mysql_num_rows($sale_qty_query)==''){
									echo $r['qty'];
								}else{
									while($sr = mysql_fetch_array($sale_qty_query)){
										while($br = mysql_fetch_array($buy_qty_query)){
											echo $stock_qty = $br['sum(qty)'] - $sr['sum(qty)'];
											
										}
									}
								}
							  echo '</td>';
							  echo '<td>';
							  $daily_buy_total_buy_query = mysql_query("select sum(total) from daily_buy where product='$r[product]'");
							  while($dbtq = mysql_fetch_array($daily_buy_total_buy_query)){
								  echo number_format($dbtq['sum(total)'],2);
							  } 
							  echo '</td>';
							  echo '<td>';
							  $daily_sale_total_query = mysql_query("select * from daily_sale where product='$r[product]'");
							  if(mysql_num_rows($daily_sale_total_query)==null){
									  echo '0';
							  }else{
									$daily_sale_total_qty_query = mysql_query("select sum(qty) from daily_sale where product='$r[product]'");
									while($rtq = mysql_fetch_array($daily_sale_total_qty_query)){
										$daily_buy_total_buy_query = mysql_query("select sum(total),sum(qty) from daily_buy where product='$r[product]'");
										  while($dbtq = mysql_fetch_array($daily_buy_total_buy_query)){
											  $unit_price_for_sale = $dbtq['sum(total)'] / $dbtq['sum(qty)'];
											  $final_price = $unit_price_for_sale * $rtq['sum(qty)'];
											  echo number_format($final_price,2);
										  } 
									}
							  }							  
							  echo '</td>';
							  echo '<td>';
							   $daily_sale_total_query2 = mysql_query("select * from daily_sale where product='$r[product]'");
							  if(mysql_num_rows($daily_sale_total_query2)==null){
									  $a = mysql_fetch_array(mysql_query("select sum(total),sum(qty) from daily_buy where product='$r[product]'"));
									  echo $b = $a['sum(total)'];
							  }else{
										$buy_qty_query2 = mysql_query("select sum(qty),sum(total) from daily_buy where product='$r[product]'");
										$sale_qty_query2 = mysql_query("select sum(qty) from daily_sale where product='$r[product]'");
										while($sr = mysql_fetch_array($sale_qty_query2)){
											while($br = mysql_fetch_array($buy_qty_query2)){
												$stock_qty2 = $br['sum(qty)'] - $sr['sum(qty)'];
												$unit_price_for_sale2 = $br['sum(total)'] / $br['sum(qty)'];
											    $final_price_2 = $unit_price_for_sale2 * $stock_qty2;
												echo number_format($final_price_2,2);
												
												
											}
										}
										
									
							  }	
								
							  echo '</td>';
						  echo '</tr>';	
				}
				//This is for GRAND TOTAL all section
				
				echo '<th></th><th style="border-top:1px solid black">';
				
							  $total = mysql_query("select sum(qty) from daily_buy");
							  while($t = mysql_fetch_array($total)){
								  echo $t['sum(qty)'];
							  }
							  echo '</th>';
							  //End total section 
							  //This is Sold section
							  echo '<th style="border-top:1px solid black">';
							  $sold = mysql_query("select sum(qty) from daily_sale");
							  while($s = mysql_fetch_array($sold)){
								  echo $s['sum(qty)'];
							  }
							  echo '</th>';
							  //End Sold section 
							  echo '<th style="border-top:1px solid black">';
								$buy_qty_query = mysql_query("select sum(qty) from daily_buy");
								$sale_qty_query = mysql_query("select sum(qty) from daily_sale");
								if(mysql_num_rows($sale_qty_query)==''){
									echo $r['qty'];
								}else{
									while($sr = mysql_fetch_array($sale_qty_query)){
										while($br = mysql_fetch_array($buy_qty_query)){
											echo $stock_qty = $br['sum(qty)'] - $sr['sum(qty)'];
											
										}
									}
								}
							  echo '</th>';
							  echo '<th style="border-top:1px solid black">';
							  $daily_buy_total_buy_query = mysql_query("select sum(total) from daily_buy");
							  while($dbtq = mysql_fetch_array($daily_buy_total_buy_query)){
								  echo number_format($dbtq['sum(total)'],2);
							  } 
							  echo '</th>';
							  echo '<th style="border-top:1px solid black">';
							  $daily_sale_total_query = mysql_query("select * from daily_sale");
							  if(mysql_num_rows($daily_sale_total_query)==null){
									  echo '0';
							  }else{
									$query5 = mysql_query("select * from daily_buy group by product having count(*) >=1");
									while($r5 = mysql_fetch_array($query5)){
											$daily_sale_total_qty_query5 = mysql_query("select sum(qty) from daily_sale where product='$r5[product]'");
											while($rtq5 = mysql_fetch_array($daily_sale_total_qty_query5)){
												$daily_buy_total_buy_query5 = mysql_query("select sum(total),sum(qty) from daily_buy where product='$r5[product]'");
												  while($dbtq5 = mysql_fetch_array($daily_buy_total_buy_query5)){
													  $unit_price_for_sale5 = $dbtq5['sum(total)'] / $dbtq5['sum(qty)'];
													  $final_price5 = $unit_price_for_sale5 * $rtq5['sum(qty)'];
													  $array = array('a'=>$final_price5);
														foreach($array as $num => $values) {
														
															$vatAmount5[] = $values;
														}
												  } 
											}
											
									}
									$Total = array_sum($vatAmount5);
									echo $final_price_5 = number_format($Total,2);
							  }							  
							  echo '</th>';
							  echo '<th style="border-top:1px solid black">';
							   $daily_sale_total_query2 = mysql_query("select * from daily_sale");
							  if(mysql_num_rows($daily_sale_total_query2)==null){
									  $a = mysql_fetch_array(mysql_query("select sum(total),sum(qty) from daily_buy"));
									  echo $b = $a['sum(total)'];
							  }else{
								    $query = mysql_query("select * from daily_buy group by product having count(product) >=1");
									while($r = mysql_fetch_array($query)){
										$buy_qty_query3 = mysql_query("select sum(qty),sum(total) from daily_buy where product='$r[product]'");
										$sale_qty_query3 = mysql_query("select sum(qty) from daily_sale where product='$r[product]'");
										while($sr= mysql_fetch_array($sale_qty_query3)){
											while($br = mysql_fetch_array($buy_qty_query3)){
												
												
												$stock_qty3 = $br['sum(qty)'] - $sr['sum(qty)'];
												
												$unit_price_for_sale3 = $br['sum(total)'] / $br['sum(qty)'];
											    $final_price_3 = $unit_price_for_sale3 * $stock_qty3;
												$array = array('a'=>$final_price_3);
												foreach($array as $num => $values) {
												
													$vatAmount[] = $values;
												}

												
												
											}
										}
									}
									$Total6 = array_sum($vatAmount);
									echo $final_price_6 = number_format($Total6,2);
									
							  }	
								
							  echo '</th>';
				
		echo '</table>';
		
}
require_once('footer.php');
?>
<script src="jquery.js"></script>
<script>
$(document).ready(function(){
	$(".th").css("border","none");
})
</script>