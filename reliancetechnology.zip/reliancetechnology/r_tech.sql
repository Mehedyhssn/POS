

CREATE TABLE `balance` (
  `balance_ID` int(11) NOT NULL AUTO_INCREMENT,
  `dated` date NOT NULL,
  `spent` varchar(11) NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`balance_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


INSERT INTO balance VALUES
("1","2016-09-09","Modem","500");




CREATE TABLE `customer` (
  `customer_ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `address` varchar(200) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  PRIMARY KEY (`customer_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;


INSERT INTO customer VALUES
("36","Mehedy","Dinajpur","01737091500"),
("37","Mubaddir","Dinajpur","01737091555"),
("38","Taher","asdf","0127888888"),
("39","Taher Thakur","Gobindagonj,Gaibandha","01737091599");




CREATE TABLE `customer_sale_report` (
  `cust_sale_rep` int(11) NOT NULL AUTO_INCREMENT,
  `customer_ID` int(11) NOT NULL,
  `dated` date NOT NULL,
  `grand_total` int(11) NOT NULL,
  `previous_deu` int(11) NOT NULL,
  `collection` int(11) NOT NULL,
  `net_outstanding` int(11) NOT NULL,
  PRIMARY KEY (`cust_sale_rep`),
  KEY `customer_ID` (`customer_ID`),
  CONSTRAINT `customer_sale_report_ibfk_1` FOREIGN KEY (`customer_ID`) REFERENCES `customer` (`customer_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;


INSERT INTO customer_sale_report VALUES
("1","36","2016-09-04","3980","0","3900","-80"),
("2","36","2016-09-04","12150","80","12000","-230"),
("3","36","2016-09-04","7900","230","8000","-130"),
("18","36","2016-09-05","7900","230","8100","30"),
("19","36","2016-09-05","7900","230","8130","0"),
("20","36","2016-09-05","3950","0","3000","-950"),
("21","36","2016-09-05","3950","0","3900","50"),
("22","36","2016-09-09","3950","0","3925","25");




CREATE TABLE `daily_buy` (
  `dailybuy_ID` int(11) NOT NULL AUTO_INCREMENT,
  `dated` date NOT NULL,
  `product` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `wnty` int(11) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `company` varchar(100) NOT NULL,
  PRIMARY KEY (`dailybuy_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=latin1;


INSERT INTO daily_buy VALUES
("129","2016-09-01","Hard Disk","Toshiba","1TB","365","3850","1","3850","Torent"),
("130","2016-09-02","Hard Disk","Toshiba","1TB","365","3850","1","3850","Torent"),
("131","2016-09-02","Hard Disk","Toshiba","1TB","365","3850","1","3850","Torent");




CREATE TABLE `daily_sale` (
  `dailysale_ID` int(11) NOT NULL AUTO_INCREMENT,
  `customer_ID` int(11) NOT NULL,
  `order_no` varchar(150) NOT NULL,
  `sold_by` varchar(100) NOT NULL,
  `dated` date NOT NULL,
  `product` varchar(150) NOT NULL,
  `brand` varchar(150) NOT NULL,
  `model` varchar(50) NOT NULL,
  `sl` varchar(100) NOT NULL,
  `wnty` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `buy_price` int(11) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `grand_total` int(11) NOT NULL,
  `grand_profit` int(11) NOT NULL,
  PRIMARY KEY (`dailysale_ID`),
  KEY `customer_ID` (`customer_ID`),
  CONSTRAINT `daily_sale_ibfk_1` FOREIGN KEY (`customer_ID`) REFERENCES `customer` (`customer_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;


INSERT INTO daily_sale VALUES
("1","36","RT164935","Mehedy","2016-09-04","Hard Disk","Toshiba","1TB","TYO012,KILO115","365","2","3850","3950","7900","200"),
("2","36","RT1666912","K","2016-09-05","Hard Disk","Toshiba","1TB","KOIS","365","1","3850","3950","3950","100");




CREATE TABLE `sl` (
  `si_id` int(11) NOT NULL AUTO_INCREMENT,
  `daily_buy_id` int(11) NOT NULL,
  `si_no` varchar(100) NOT NULL,
  `status` varchar(5) NOT NULL,
  PRIMARY KEY (`si_id`),
  KEY `daily_buy_id` (`daily_buy_id`),
  CONSTRAINT `sl_ibfk_1` FOREIGN KEY (`daily_buy_id`) REFERENCES `daily_buy` (`dailybuy_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;


INSERT INTO sl VALUES
("63","129","TYO012","off"),
("64","130","KILO115","off"),
("65","131","KOIS","off");




CREATE TABLE `warrenty` (
  `warr_id` int(11) NOT NULL,
  `send_date` date NOT NULL,
  `send_media` varchar(150) NOT NULL,
  `received_date` date NOT NULL,
  `product_name` varchar(150) NOT NULL,
  `problem` varchar(150) NOT NULL,
  `qty` int(11) NOT NULL,
  `sn` varchar(150) NOT NULL,
  `new_sn` varchar(150) NOT NULL,
  `customer_info` varchar(150) NOT NULL,
  `receive` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




