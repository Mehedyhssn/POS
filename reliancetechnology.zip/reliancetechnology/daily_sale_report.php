<?php
require_once('connection.php');
require_once('header.php');
echo '<h1 style="text-align:center;margin-bottom:15px">Daily Sale</h1>';
function daily_sale(){
	
	$page = @$_GET['page'];
	
	if($page=='' || $page==1){
		$page1 = 0;
	}else{
		$page1 = ($page*15)-15;
	}	
	
	//Query from daily buy table
	$query = mysql_query("select * from daily_sale limit $page1,15");
	echo '<form method="get"><table style="text-align:center"><th colspan="11">Daily Sale Products Reports!!</th>';
	echo '<tr>
	<th class="grey">Date</th>
	<th class="grey">Product</th>
	<th class="grey">Brand</th>
	<th class="grey">Model</th>
	<th class="grey">Serial</th>
	<th class="grey">Warrenty</th>
	<th class="grey">Unit Price</th>
	<th class="grey">Qty.</th>
	<th class="grey">Grand Total</th>
	<th class="grey" colspan="2">Actions</th>
	</tr>';
	while( $rows = mysql_fetch_array($query) ){
		echo '<tr><td>'.$rows['dated'].'</td>
				  <td>'.$rows['product'].'</td>
				  <td>'.$rows['brand'].'</td>
				  <td>'.$rows['model'].'</td>
				  <td>'.$rows['sl'].'</td>
				  <td>'.$rows['wnty'].'</td>
				  <td>'.$rows['unit_price'].'</td>
				  <td>'.$rows['qty'].'</td>
				  <td>'.$rows['grand_total'].'</td>
				  
				  <td><a style="color:green;font-weight:bold;font-style: italic;" href="daily_sale_report.php?edit='.$rows['dailysale_ID'].'">Edit</a></td>
				  <td><a style="color:red;font-weight:bold;font-style: italic;" href="daily_sale_report.php?delete='.$rows['dailysale_ID'].'" class="delete">Delete</a></td></tr>';
	}
	echo '</table></form><div id="delete_ok"></div>';
	//this is for paging sections
	$result = mysql_query("select * from daily_sale");
	$num_of_rows = mysql_num_rows($result);
	$a = $num_of_rows/15;
	$a = ceil($a);
	for($i=1;$i<=$a;$i++){
		echo '<br><br><a href="daily_sale_report.php?page='.$i.'" style="text-decoration:none">'.$i.'</a>';
	}
}
//Edit Section
function edit(){
		if(isset($_GET['edit'])){
				echo '<form method="get" action="daily_sale_report.php"><table style="margin:0 auto; width:250px;">';
					$query = mysql_query("select * from daily_sale where dailysale_ID='$_GET[edit]'");
					while( $rows = mysql_fetch_array($query) ){
						echo '<tr>
								  <th class="grey">Dated</th>
								  <th class="grey">Product</th>
								  <th class="grey">Brand</th>
								  <th class="grey">Model</th>
								  <th class="grey">Serial</th>
								  <th class="grey">Warrenty</th>
								  <th class="grey">Unit Price</th>
								  <th class="grey">Qty</th>
								  <th class="grey">Total</th>
								  <th class="grey">Action</th>
							</tr>
							<tr>
							  <td><input size="7" type="text" name="dated" value="'.$rows['dated'].'"></td>
							  <td><input size="7" type="text" name="product" value="'.$rows['product'].'"></td>
							  <td><input size="7" type="text" name="brand" value="'.$rows['brand'].'"></td> 
							  <td><input size="7" type="text" name="model" value="'.$rows['model'].'"></td>  
							  <td><input size="7" type="text" name="sl" value="'.$rows['sl'].'"></td>	 
							  <td><input size="7" type="text" name="wnty" value="'.$rows['wnty'].'"></td>	  
							  <td><input size="8" class="unit_price" type="text" name="unit_price" value="'.$rows['unit_price'].'"></td> 
							  <td><input size="7" class="qty" type="text" name="qty" value="'.$rows['qty'].'"></td> 
							  <td><input size="7" class="total" type="text" name="grand_total" value="'.$rows['grand_total'].'"></td>
							  <td><input style="font-weight:bold;color:red;font-style:italic" type="submit" value="Update"/><input type="hidden" name="update" value="'.$rows['dailysale_ID'].'"></td>
                            </tr>							  
						    <tr>';
					}
				echo '</table>';
		}
}
function update(){
	if(isset($_GET['update'])){
					
			mysql_query("update daily_sale set 
							dated = '$_GET[dated]',
							product = '$_GET[product]',
						    brand = '$_GET[brand]',
							model = '$_GET[model]',
							sl = '$_GET[sl]',
							wnty = '$_GET[wnty]',
							unit_price = '$_GET[unit_price]',
							qty = '$_GET[qty]',
							grand_total = '$_GET[grand_total]'
							
									
							where dailysale_ID = '$_GET[update]'
						");
			
			
		}
	echo 'Successfully Updated';
	header('Location: http://localhost/reliancetechnology/daily_sale_report.php');
}
function product_delete(){
	if( isset($_GET['delete']) ){
		//Alerming to delete
		 $id = $_GET['delete'];
		?>
		<script>
		$( document ).ready(function(e) {
		  var r = confirm("Are you sure to delete?");
		  var id = '<?php echo $id; ?>';
		  if(r==true){
			 $.ajax({
					type: "GET",
					data:{
						"delete_sale": 1,
						 "id" : id
					}, 
					url: "allfilesAjax.php",
					success: function(e){
						window.location.assign("http://localhost/reliancetechnology/daily_sale_report.php")
										
				    }
				});
				$.ajax({
					type: "GET",
					data:{
						"delete_sale": 1,
						 "id" : id
					}, 
					url: "slUpdate.php",
					success: function(e){
						
						window.location.assign("http://localhost/reliancetechnology/daily_sale_report.php")
										
				    }
				});
		  }else{
			  window.location.assign("http://localhost/reliancetechnology/daily_sale_report.php")
		  }
		})
		</script>
		<?php 
	}
}
if(isset($_GET['edit'])){
	edit();
}elseif(isset($_GET['update'])){
	update();
}elseif(isset($_GET['delete'])){
	product_delete();
}else{
	daily_sale();
}
require_once('footer.php');
?>
<!-- Jquery for addition on purchase page -->
<script>
$(document).ready(function(){
	$('.unit_price').keyup(function(){
		var unit_price = $(this).val();
		var qty = $('.qty').val();
		var total = unit_price * qty;
		$('.total').val(total);
	})
	$('.qty').keyup(function(){
		var qty = $(this).val();
		var unit_price = $('.unit_price').val();
		var total = unit_price * qty;
		$('.total').val(total);
	})
})
</script>