<?php
require_once("connection.php");
require_once("header.php");
echo '<h1 style="text-align:center;margin-bottom:15px">Purchase</h1>';
if(isset($_POST['add'])){
	
	if( empty($_POST['product'])
		or empty($_POST['brand'])
	    or empty($_POST['model'])
		or empty($_POST['up'])
		or empty($_POST['qty'])
		or empty($_POST['company'])
	){
		echo '<script>alert("fill all fields!!")</script>';
	}else{
		$sl = $_POST['sl'];
		
		for($i=0;$i<count($sl);$i++){
			
		$date = mysql_fetch_array(mysql_query("SELECT CURRENT_DATE"));
		$current_date = $date['CURRENT_DATE'];
		$qty = $_POST['qty']/$_POST['qty'];
		$total = $qty * $_POST['up'];
		mysql_query("insert into daily_buy(`dated`,`product`,`brand`,`model`,`wnty`,`unit_price`,`qty`,`total`,`company`) 
		                            values ('$current_date','$_POST[product]','$_POST[brand]','$_POST[model]',
									'$_POST[wnty]','$_POST[up]','$qty ','$total','$_POST[company]')");
		$daily_buy_id = mysql_fetch_array(mysql_query("select dailybuy_ID from daily_buy order by dailybuy_ID desc limit 1"));							
		
			mysql_query("insert into sl(`si_id`,`daily_buy_id`,`si_no`,`status`) 
		                            values ('','$daily_buy_id[dailybuy_ID]','$sl[$i]','on')");  
		
		}
		
	}
	
	
}
?>
<form method="POST" action="index.php" id="proinfo">
	<fieldset>
		<legend>ADD PRODUCTS</legend>
		<table style="margin-bottom:10px">
		<tr><td style="width:180px"><label style="width:180px">Product:</label></td><td style="width:750px"><input style="font-size: 20px;width:770px;height: 30px;" type="text"  name="product" id="product"/></td><tr>
		<tr><td><label>Brand:</label></td><td><input style="font-size: 20px;width:770px;height: 30px;" type="text"  name="brand" id="brand"/></td><tr>
		<tr><td><label>Model:</label></td><td><input style="font-size: 20px;width:770px;height: 30px;" type="text" name="model" id="model"/></td><tr>
		<tr><td><label>S/N :</label></td><td><input style="font-size: 20px;width:770px;height: 30px;" type="text" autocomplete="off" name="sl[]" id="sl" value="0"/></td><td><input type="button" style="cursor:pointer;font-size:15px;color:red;font-weight:bold" class="ui-icon-plusthick" value="+"></td>
																					<td><input type="button" style="cursor:pointer;font-size:15px;color:red;font-weight:bold" class="ui-icon-minusthick" value="-"></td><tr>
																<tr><td></td><td><span class="sn"></span></td><tr>
		<tr><td><label>Warrenty :</label></td><td><input style="font-size: 20px;width:770px;height: 30px;" type="text"  name="wnty" value="0"/></td><tr>
		<tr><td><label style="font-size:15px">Unit Price :</label></td><td><input style="font-size: 20px;width:770px;height: 30px;" type="text"  name="up" id="up"/></td><tr>
		<tr><td><label>Quantity :</label></td><td><input style="font-size: 20px;width:770px;height: 30px;" type="text"  name="qty" id="qty"/></td><tr>
		<tr><td><label>Company:</label></td><td><input style="font-size: 20px;width:770px;height: 30px;" type="text"  name="company" id="company"/></td><tr>
		</table>
		<input style="cursor:pointer;color:red;width:100%;font-style:italic;font-size:30px" type="submit" name="add" value="ADD"/>
																
	</fieldset>
</form>
<?php 

require_once("footer.php");
?>
<script>
$(document).ready(function(){
	var product = [<?php 
					$query = mysql_query("select product from daily_buy group by product having count(*)>=1");
					while($r=mysql_fetch_array($query)){
						echo '"'.$r['product'].'",';
					}				  
				  ?>];
				   $("#product").autocomplete({
					   source : product
				   })
	var brand = [<?php 
					$query = mysql_query("select brand from daily_buy group by brand having count(*)>=1");
					while($r=mysql_fetch_array($query)){
						echo '"'.$r['brand'].'",';
					}				  
				  ?>];
				   $("#brand").autocomplete({
					   source : brand
				   })
    var model = [<?php 
					$query = mysql_query("select model from daily_buy group by model having count(*)>=1");
					while($r=mysql_fetch_array($query)){
						echo '"'.$r['model'].'",';
					}				  
				  ?>];
				   $("#model").autocomplete({
					   source : model
				   })		
	
	var i = 1;
	$(".ui-icon-plusthick").click(function(){
		$(".sn").append("<span class='count'><input placeholder='Serial No' style='font-size: 20px;width:770px;height: 30px;margin:10px 0' type='text' autocomplete='off' name='sl[]' id='sl'/></span>");
		i++;
	})
	$(".ui-icon-minusthick").click(function(){
		$(".sn").find(".count:nth-child(1)").remove();
	})
	var company = [<?php 
					$query = mysql_query("select company from daily_buy group by company having count(*)>=1");
					while($r=mysql_fetch_array($query)){
						echo '"'.$r['company'].'",';
					}				  
				  ?>];
				   $("#company").autocomplete({
					   source : company
				   })
	
})
</script>