<html>
<head>
<title>Welcome to Stock Management System</title>
<script src="jquery.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<script src="jquery-ui.js" type="text/javascript"></script>
<link href="jquery-ui.css" rel="stylesheet">
<script>
    $(document).ready(function() {
        $( '.dropdown' ).hover(
            function(){
                $(this).children('.sub-menu').slideDown(200);
            },
            function(){
                $(this).children('.sub-menu').slideUp(200);
            }
        );
    }); // end ready
</script>
</head>
<a href="index.php"><img class="img" src="images/reliance.jpg" /></a>
<?php
echo '<nav>
    <ul class="content clearfix">
        <li class="dropdown">
			<a href="index.php">Purchase</a>
			<ul class="sub-menu">
				<li><a href="purchase.php">Daily Buy</a></li>	 
			</ul>
		</li>
        <li class="dropdown">
			<a href="sale.php">Sale Product</a>
			<ul class="sub-menu">
				<li><a href="daily_sale_report.php">Daily Sale</a></li>	 
			</ul>
		</li>
		 <li><a href="stock.php">Stock</a></li>
		 
		 <li><a href="customer_report.php">Collection</a></li>
	  
	   <li><a href="AddCustomerPage.php">Add Customer</a></li>
        <li class="dropdown">
            <a href="#">Report</a>
            <ul class="sub-menu">
			     <li><a href="dailybuyreport.php">Daily Buy Report</a></li>
                 <li><a href="dailysalereport.php">Daily Sale Report</a></li> 
				 <li><a href="balance_report.php">Cash Report</a></li> 
                  			  
            </ul>
        </li>
		<li><a href="backup.php">Back Up</a></li>
		<li><a href="balance.php">Balance</a></li>
		<li><a href="warrenty.php">Warrenty</a></li>
        
    </ul>
</nav><div id="wrapper">';
?>