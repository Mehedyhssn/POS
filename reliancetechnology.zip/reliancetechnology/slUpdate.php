<?php
require_once("connection.php");
 if(isset($_GET['delete_sale'])){
	 
	 $id = $_GET['id'];
	 $q = mysql_query("select * from daily_sale where dailysale_ID='$id'");
	 while($r=mysql_fetch_array($q)){
				 
		$s = rtrim($r['sl'],",");
		$sl_array = explode(',', $s);
		foreach($sl_array as $value){
			mysql_query("update sl set status='on' where si_no='$value'");
		} 
	 } 
 }
?>