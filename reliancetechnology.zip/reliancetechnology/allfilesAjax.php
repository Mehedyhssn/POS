<?php
require_once('connection.php');
 //AJAX Request
if(isset($_GET['search_product'])){
	$product = mysql_query("select * from daily_buy where `product` LIKE '%$_GET[product]%' group by product having count(*) >=1");
	while($r = mysql_fetch_array($product)){
		if($r['product']==''){
			echo '';
		}else{
		echo '<li>'.$r['product'].'</li>';
		}
		
	}
exit();	
}
if(isset($_GET['search_brand'])){
	$product = mysql_query("select * from daily_buy where `brand` LIKE '%$_GET[brand]%' group by brand having count(*) >=1");
	while($r = mysql_fetch_array($product)){
		if($r['brand']==''){
			echo '';
		}else{
		echo '<li>'.$r['brand'].'</li>';
		}
	}
exit();	
}
if(isset($_GET['search_model'])){
	$product = mysql_query("select * from daily_buy where `model` LIKE '%$_GET[model]%' group by model having count(*) >=1");
	while($r = mysql_fetch_array($product)){
		if($r['model']==''){
			echo '';
		}else{
		echo '<li>'.$r['model'].'</li>';
		}
	}
exit();	
}
if(isset($_GET['search_company'])){
	$product = mysql_query("select * from daily_buy where `company` LIKE '%$_GET[company]%' group by company having count(*) >=1");
	while($r = mysql_fetch_array($product)){
		if($r['company']==''){
			echo '';
		}else{
		echo '<li>'.$r['company'].'</li>';
		}
	}
exit();	
}
//////////////////////////// THIS IS SALE PAGE AJAX/////////////////////////////////////////////////
if(isset($_GET['search_contact'])){
	$product = mysql_query("select * from customer where `mobile` LIKE '%$_GET[contact]%' group by mobile having count(*) >=1");
	while($r = mysql_fetch_array($product)){
		if($r['mobile']==''){
			echo '';
		}else{
		echo '<li value="'.$r['customer_ID'].'">'.$r['mobile'].'</li>';
		}
	}
exit();	
}
if(isset($_GET['mobile_with_customer_id'])){
	$customer_ID = mysql_query("select * from customer where `mobile`='$_GET[mobile_with_customer_id]'");
	while($c_ID = mysql_fetch_array($customer_ID)){
		if($c_ID['mobile']==''){
			echo '';
		}else{
		echo $c_ID['customer_ID'];;
		}
	}
exit();	
}

//////////////////////////////////////////////////////////////////////////////
 if(isset($_GET['id'])){
	 $id = $_GET['id'];
	 mysql_query("DELETE FROM `daily_buy` WHERE dailybuy_ID='".$id."'");
 }
 if(isset($_GET['delete_sale'])){
	 $id = $_GET['id'];
	 mysql_query("DELETE FROM `daily_sale` WHERE dailysale_ID='".$id."'");
 }

     

//This is for retriving stock product
if(isset($_GET['product_stock_qty'])){
	$query = mysql_query("select * from daily_buy where product='$_GET[product]' and brand='$_GET[brand]' and model='$_GET[model]' having count(*) >=1");
	while($r = mysql_fetch_array($query)){
			$buy_qty_query = mysql_query("select sum(qty) from daily_buy where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
										$sale_qty_query = mysql_query("select sum(qty) from daily_sale where product='$r[product]' and brand='$r[brand]' and model='$r[model]'");
										if(mysql_num_rows($sale_qty_query)==''){
											echo $r['qty'];
										}else{
											while($sr = mysql_fetch_array($sale_qty_query)){
												while($br = mysql_fetch_array($buy_qty_query)){
													echo $stock_qty = $br['sum(qty)'] - $sr['sum(qty)'];
													
												}
											}
										}

	
	}
} 
?>