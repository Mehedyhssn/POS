<?php
require_once('connection.php');
//UPDate Ajax Begins
if(isset($_GET['customer_id'])){
	print_r($_GET);
}

