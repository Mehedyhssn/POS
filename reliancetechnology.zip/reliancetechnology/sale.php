<?php
//session_start();
require_once('connection.php');
require_once('header.php');
echo '<h1 style="text-align:center;margin-bottom:15px">Sale Product</h1>';
?>
<?php
function daily_buy_product(){
	$q = mysql_query("SELECT * FROM `daily_buy` GROUP BY product");
	echo '<select class="product" name="product"><option selected>--</option>';
	while($r = mysql_fetch_array($q)){
		echo '<option value="'.$r['product'].'">'.$r['product'].'</option>';
	}
	echo '</select>';
}
/* function customer(){
	$q = mysql_query("select * from customer");
	echo '<select name="customers_name_and_id" class="customer_ID"><option>--</option>';
	while($r=mysql_fetch_array($q)){
		echo '<option value="'.$r['customer_ID'].'">'.$r['mobile'].'</option>';
	}
	echo '</select>';
} */
function dated(){
	$dated = mysql_query('SELECT curdate();');
	$date = mysql_fetch_assoc($dated);
	$curr_date = $date['curdate()'];
	echo $curr_date;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

?>
	<form method="GET" action="customer.php" id="submit">
		<table style="margin-bottom:50px;border:0;width:100%">
			
			<tr style="margin-bottom:10px;">
				<td class="order">Order No: <input style="border:none" type="text" name="order_no" class="order_no" value="<?php echo 'RT'.date('y').rand(100,99999); ?>"/></td>
				<td>Contact No: <input  value="" name="contact" id="contact"/></td>
				<td>Date :<?php dated();?><input name="curdate" type="hidden" value="<?php dated();?>" class="current_dated"></td>
				<td style="border:none"><input type="hidden" name="customer_id" class="customer_id" value="" /></td>
				<td style="border:none"><input type="hidden" class="hidden_sold_by" value="" name="sold_by"/></td>
			</tr>
			<tr class="address" style="margin-bottom:10px;">	
			</tr>
			
			
		</table>
		<table style="text-align:center;">
			<th class="grey">Product</th><th class="grey">Brand</th><th class="grey">Model</th><th class="grey">sl</th><th class="grey">wnty</th><th class="grey">BP</th><th class="grey">SQT</th><th class="grey">Qty</th><th class="grey">Sale Price</th><th class="grey">Total</th>
			<tr><td><?php daily_buy_product();?></td><td><span class="brand"></span></td><td><span class="model"></span></td><td><span class="sl"></span></td>
			<td><span class="wnty"></span></td><td><span class="bp"></span></td><td><span class="stock_qty stock"></span></td><td><input type="text" class="stokqty stokqty2" name="qty" value=""/></td><td><input name="unit_price" type="text" class="sp"/></td><td><input type="text" style="border:none;text-align:center;" class="total"/></td></tr>
			<tr style="border:none;display:none;">
				<td style="border:none"><input type="hidden" name="product" id="product"/></td>
				<td style="border:none"><input type="hidden" name="brand" id="brand"/></td>
				<td style="border:none"><input type="hidden" name="model" id="model"/></td>
				<td style="border:none"><input type="hidden" name="sl" id="sl"/></td>
				<td style="border:none"><input type="hidden" name="wnty" id="wnty"/></td></tr>
				
		</table>
		<span class="customer_sold"></span>
	</form>
<?php
require_once('footer.php');
?>
<script>
$(document).ready(function(e){
	
	//Geting the contact number
	var contact = [<?php 
							$query = mysql_query("select * from customer group by mobile having count(*)>=1");
							while($r=mysql_fetch_array($query)){
								echo '"'.$r["mobile"].'",';
							}
						?>];
						
   	$( "#contact" ).autocomplete({
		source : contact,
		select: function(e,ui) {
			
			if(e.keyCode==13){
				
				var mobile = $(this).val();
				var order_no = $(".order_no").val();
				//Ajax
				$.ajax({
							type: "GET",
							data:{
								 "mobile" : mobile
								 
							}, 
							url: "saleAjax.php",
							success: function(e){
								$(".address").html(e);										
							}
				});//End Ajax
				//Ajax
				$.ajax({
							type: "GET",
							data:{
								 
								 "mobile_with_customer_id" : mobile
							}, 
							url: "allfilesAjax.php",
							success: function(e){
								$(".customer_id").val(e);										
							}
				});//End Ajax
				
				
			}else if(e.button==0){
				
				var mobile = ui.item.value;
				var order_no = $(".order_no").val();
				//Ajax
				$.ajax({
							type: "GET",
							data:{
								 "mobile" : mobile
								 
							}, 
							url: "saleAjax.php",
							success: function(e){
								$(".address").html(e);										
							}
				});//End Ajax
				//Ajax
				$.ajax({
							type: "GET",
							data:{
								 
								 "mobile_with_customer_id" : mobile
							}, 
							url: "allfilesAjax.php",
							success: function(e){
								$(".customer_id").val(e);										
							}
				});//End Ajax
				
			}
         
		}
		
	});
	$("body").delegate(".sold_by","keyup",function(e){
		var sold_by = $(this).val();
		$(".hidden_sold_by").val(sold_by);
		
	})
						
		
	
	// Get the mobile number
	$( "body" ).delegate( ".address select", "change", function() {
		var address = $(this).val();
		var customer = $('.customer option:selected').val();
		$.ajax({
					type: "GET",
					data:{
						 "address" : address,
						 "customer" : customer
					}, 
					url: "saleAjax.php",
					success: function(e){
						$(".mobile").html(e);
						$('.mobile select:nth-child(1)').hide();
					}
		});//End Ajax
	});
	//sending product data
	$(".product").change(function(){
		var product = $(this).val();
		$('#product').val(product);
		$.ajax({
					type: "GET",
					data:{
						 "product" : product
					}, 
					url: "saleAjax.php",
					success: function(e){
						$(".brand").html(e);										
				    }
		});//End Ajax
		
	});
	//Sending brand data
	
	$( "body" ).delegate( ".brand select", "change", function() {
		var brand = $(this).val();
		$('#brand').val(brand);
		var product = $('.product option:selected').val();
		$.ajax({
					type: "GET",
					data:{
						 "product" : product,
						 "brand" : brand
					}, 
					url: "saleAjax.php",
					success: function(e){
						$(".model").html(e);
						$('.model select:nth-child(1)').hide();
				    }
		});//End Ajax
	});
	//Sending the model
	$( "body" ).delegate( ".model select", "change", function(){
		var model = $(this).val();
		$('#model').val(model);
		var product = $('.product option:selected').val();
		var brand = $('.brand option:selected').val();
		$.ajax({
					type: "GET",
					data:{
						 "model" : model,
						 "product" : product,
						 "brand" : brand 
					}, 
					url: "saleAjax.php",
					success: function(e){
						$(".sl").html(e);
						
						$('.sl select:nth-child(1)').hide();
						$('.sl select:nth-child(2)').hide();
				    }
		});//End Ajax
		$.ajax({
					type: "GET",
					data:{
						 "product_stock_qty" : 1,
						 "product" : product,
						 "brand" : brand,
						 "model" : model
					}, 
					url: "allfilesAjax.php",
					success: function(e){
						
					    $(".stock_qty").text(e);
						$('.stock_qty select:nth-child(1)').remove();
						$('.stock_qty select:nth-child(2)').remove();	
						$('.stock_qty select:nth-child(3)').remove();
                        var stock = $(".stock_qty").text();
                       if(stock==0){
						   $('.stokqty2').prop('disabled',true);
						   $('.sp').prop('disabled',true);						   
					   }else{
						  $('.stokqty2').prop('disabled',false);
						   $('.sp').prop('disabled',false);
					   }					
					
						
				    }
				
		});//End Ajax
	});
	//Sending the sl
	$( "body" ).delegate( ".sl select", "change", function(){
		    var str = "";
			$( ".sl select option:selected" ).each(function() {
		     str += $( this ).val() + ",";
		   });
		   var sl=str.replace("0,0,","");
		   var stockqty = $('.sl select option:selected').size(); 	   
		   $(".stokqty").val(stockqty-2);
		var product = $('.product option:selected').val();
		var brand = $('.brand option:selected').val();
		var model = $('.model select:nth-child(2) option:selected').val();
		$.ajax({
					type: "GET",
					data:{
						 "sl" : sl,
						 "model" : model,
						 "product" : product,
						 "brand" : brand 
						 
					}, 
					url: "saleAjax.php",
					success: function(e){
						$(".wnty").html(e);	
						$('.wnty select:nth-child(1)').hide();
						$('.wnty select:nth-child(2)').hide();
						$('.wnty select:nth-child(3)').hide();
						
				    }
		});//End Ajax
	});
	//Sending the wnty
	$( "body" ).delegate( ".wnty select", "change", function(){
		var wnty = $(this).val();
		$('#wnty').val(wnty);
		var product = $('.product option:selected').val();
		var brand = $('.brand option:selected').val();
		var model = $('.model select:nth-child(2) option:selected').val();
		var sl = $('.sl select:nth-child(3) option:selected').val();
		$.ajax({
					type: "GET",
					data:{
						 "wnty" : wnty,
						 "sl" : sl,
						 "model" : model,
						 "product" : product,
						 "brand" : brand 
					}, 
					url: "saleAjax.php",
					success: function(e){
						$(".bp").html(e);
						$('.bp select:nth-child(1)').hide();
						$('.bp select:nth-child(2)').hide();
						$('.bp select:nth-child(3)').hide();
						$('.bp select:nth-child(4)').hide();
				    }
		});//End Ajax
	});
	//Sending the product,brand,model,bp to get the ID
	//And hiding three select elements
	$( "body" ).delegate( ".bp select", "change", function(){
		var bp = $(this).val();
		var product = $('.product option:selected').val();
		var brand = $('.brand option:selected').val();
		var model = $('.model select:nth-child(2) option:selected').val();
		var sl = $('.sl select:nth-child(3) option:selected').val();
		var wnty = $('.wnty select:nth-child(4) option:selected').val();
		$.ajax({
					type: "GET",
					data:{
						 "bp" : bp,
						 "product": product,
						 "brand" : brand,
						 "model" : model,
						 "sl" : sl,
						 "wnty" : wnty 
					}, 
					url: "saleAjax.php",
					success: function(e){
						$(".id").html(e);
						$('.id select:nth-child(1)').hide();
						$('.id select:nth-child(2)').hide();
						$('.id select:nth-child(3)').hide();
						$('.id select:nth-child(4)').hide();
						$('.id select:nth-child(5)').hide();
				    }
		});//End Ajax
	});
	//Getting the qty from stock table
	$( "body" ).delegate( ".id select", "change", function(){
		var id = $(this).val();
		
		$.ajax({
					type: "GET",
					data:{
						 "id" : id						
					}, 
					url: "saleAjax.php",
					success: function(e){
						$(".qty").html(e);						
				    }
		});//End Ajax
	});
	// Calculation section
	$('.sp').keyup(function(){
		
		    var stokqty = $('.stokqty').val();
			var sale_price = $(this).val();
			var total_price = sale_price * stokqty;
			$('.total').val(total_price);
		
	})
	//Sending data with enter key
	$('.sp,.stokqty').keypress(function(e){
		    if(e.keyCode == 13){
							
				//sending data without customer
				//if( customer=='--'){
					var contact = $("#contact").val();
					var address = $('.address select option:selected').val();
					var sold_by = $('.sold_by').val();
					var customer_id = $('.customer_id').val();
					var current_dated = $('.current_dated').val();
					var product = $('.product option:selected').val();
					var brand = $('.brand select option:selected').val();
					var model = $('.model select:nth-child(2) option:selected').val();
					var checking_sl = $('.sl select:nth-child(3) option').val();
					var str = "";
					$( ".sl select option:selected" ).each(function() {
					  str += $( this ).val() + ",";
					});
					
					var sl = str.replace("0,0,","");
					var wnty = $('.wnty select:nth-child(4) option:selected').val();
					var bp = $('.bp select:nth-child(5) option:selected').val();
					var id = $('.id select:nth-child(6) option:selected').val();
					var stokqty = $('.stokqty').val();
					var sp = $('.sp').val();
					var grand_total = $(".total").val();
					var order_no = $(".order_no").val();
					
					if(contact==''){
						alert("fill up contact no!!");
						exit();
					}else if(sold_by==''){
						alert("fill up Sold By!!");
						exit();
					}else if(bp==0){
						alert("fill up BP field!!");
						exit();
					}
					//Ajax requesting
					$.ajax({
						type :	'GET',
						data : {
							"address" : address,
							"customer_id" : customer_id,
							"order_no" : order_no,
							"current_dated" : current_dated,
							"sold_by" : sold_by,
							"product" : product,
							"brand" : brand,
							"model" : model,
							"sl" : sl,
							"wnty" : wnty,
							"bp" : bp,
							"id" : id,
							"stokqty" : stokqty,
							"sp" : sp,
							"grand_total" : grand_total
							
						},
						url : 'saleAjax.php',
						success: function(){
							$("#submit").submit();		
							
						}
					})//end ajax
					//Sending data to customer ajax page
					 				 
				//End of EACH Function	
				//Sending data with customer
				//}else{
				
					//alert('Not okay');
				//}
				
				
				
			}
			
		
	})
	
	$('.stokqty').keyup(function(){
		var sale_price = $('.sp').val();
		var stokqty = $(this).val();
		var total_price = sale_price * stokqty;
		$('.total').val(total_price);
	})
	
});
</script>