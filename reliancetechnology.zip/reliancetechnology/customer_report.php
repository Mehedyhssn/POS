<?php
require_once("connection.php");
require_once("header.php");
echo '<h1 style="text-align:center;margin-bottom:15px">Collection</h1>';
if(isset($_GET['mobile'])){
	echo '<button style="color:red;font-style:italic;font-weight:bold;cursor:pointer;font-size:18px" onclick="window.history.go(-1)">Go Back</button><form method="GET" action="customer_report_update.php"><fieldset>
	            
				<legend>Calculation:</legend>';
				$query = mysql_query("select * from customer where mobile='$_GET[mobile]'");				
				while($result = mysql_fetch_array($query)){
					echo '<h2>Name : '.$result['name'].'</h2>  <h3>Address : '.$result['address'].'</h3>    <h3 style="margin-bottom:30px">Mobile :'.$result['mobile'].'</h3>';
					
								
				echo 'Previous Dues:';
					$q = mysql_query("select * from customer_sale_report where customer_ID='$result[customer_ID]' order by cust_sale_rep desc limit 0,1");				
					while($r = mysql_fetch_array($q)){
						echo $r['net_outstanding'];
						
						echo '<input type="hidden" name="net_outstanding" value="'.$r['net_outstanding'].'">';
						echo '<input type="hidden" name="db_given_collection" value="'.$r['collection'].'">';
						echo '<input type="hidden" name="db_previous_deu" value="'.$r['previous_deu'].'">';
						echo '<input type="hidden" name="customer_ID" value="'.$r['customer_ID'].'">';
						echo '<input type="hidden" name="cust_sale_rep" value="'.$r['cust_sale_rep'].'">';
						echo '<input type="hidden" name="grand_total" value="'.$r['grand_total'].'">';
					}
				}
				echo '<br>Collection : <input type="text" name="user_given_collection"/></br> ';
				
	echo '<input style="color:green;font-style:Normal;font-weight:bold;cursor:pointer;font-size:18px" type="submit" value="Update" name="Update"></form>';			
}else{
	$mobile_query = mysql_query("select * from customer");
echo '<form method="get" id="customer_report" action="customer_report.php">';
	  echo '<fieldset><legend>Query</legend>';
	  echo '<input type="text" name="mobile" placeholder="Search Mobile No:
" value="" id="mobile"/>';
	  echo '</fieldset>';
echo '</form>';
echo '<table style="margin-top:25px;width:100%;text-align:center">';
echo '<th class="th">Customer Name</th><th class="th">Address</th><th class="th">Mobile</th><th class="th">Last Dues</th>';
$due_query = mysql_query("select * from customer");
while($r=mysql_fetch_array($due_query)){
	$query_2=mysql_query("select * from customer_sale_report where customer_ID='$r[customer_ID]' order by cust_sale_rep desc limit 0,1");
	while($r2 = mysql_fetch_array($query_2)){
		echo '<tr><td>'.$r['name'].'</td><td>'.$r['address'].'</td><td>'.$r['mobile'].'</td><td>'.$r2['net_outstanding'].'</td></tr>';
	}
	
}
echo '</table>';
	
}
	  
require_once("footer.php");
?>
<script>
$(document).ready(function(){
	var mobile = [<?php 
					$query = mysql_query("select mobile from customer");
					while($r=mysql_fetch_array($query)){
						echo '"'.$r['mobile'].'",';
					}				  
				  ?>];
				   $("#mobile").autocomplete({
					   source : mobile,
					   select : function(e){
						   if(e.keyCode==13){
							  $("#customer_report").submit(); 
						   }else if(e.button==0){
							   window.setTimeout(function(){
								 $("#customer_report").submit();     
								  }, 100);
						   }
					   }
					   
				   })
})
</script>